const screen = require('../models/screens.js');
const helper = require('../service/helper.js');

// Create and Save a new User
exports.createScreens = async (req, res) => {
    let { nameEn, nameAr, image, desriptionEn, desriptionAr } = req.body;

    try {
        const newscreen = await screen.create({
            nameEn,
            nameAr,
            image,
            desriptionEn,
            desriptionAr,
            status: 1,
        });

        return res.status(201).json({
            success: true,
            data: {
                screen: newscreen,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message:
                err.message || 'Some error occurred while creating the Ticket.',
        });
        console.error(err.stack || err);
    }
};
exports.getAllScreens = async (req, res) => {
    try {
        const screensList = await screen.find({ status: 1 });
        return res.status(200).json({
            success: true,
            data: {
                screens: screensList,
            },
        });
    } catch (err) {
        res.status(400).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};
