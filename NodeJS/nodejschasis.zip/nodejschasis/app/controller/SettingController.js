const setting = require('../models/setting.js');
const helper = require('../service/helper.js');

// Create and Save a new User
exports.updateSetting = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (! result) {
        return res.status(401).json({success: false, message: 'Please login again.'});
    }

    let {
        logoImage,
        nameEn,
        nameAr,
        tageLineEn,
        tageLineAr,
        addressEn,
        addressAr,
        emailEn,
        emailAr,
        contactEn,
        contactAr,
        latitude,
        longitude,
        gMapKey,
        mapBoxKey,
        firebaseKey
    } = req.body;
    try {
        await setting.updateOne({
            _id: req.body.appId
        }, {
            logoImage: logoImage,
            nameEn: nameEn,
            nameAr: nameAr,
            tageLineEn: tageLineEn,
            tageLineAr: tageLineAr,
            addressEn: addressEn,
            addressAr: addressAr,
            emailEn: emailEn,
            emailAr: emailAr,
            contactEn: contactEn,
            contactAr: contactAr,
            latitude: latitude,
            longitude: longitude,
            gMapKey: gMapKey,
            mapBoxKey: mapBoxKey,
            firebaseKey: firebaseKey,
            status: 1
        });
        const data = await setting.findOne({_id: req.body.appId});
        return res.status(200).json({
            success: true,
            data: {
                appInfo: data
            }
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.'
        });
        console.error(err.stack || err);
    }
};

// Create and Save a new User
exports.createSetting = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (! result) {
        return res.status(400).json({success: false, message: 'Please login again.'});
    }

    let {
        logoImage,
        nameEn,
        nameAr,
        tageLineEn,
        tageLineAr,
        addressEn,
        addressAr,
        emailEn,
        emailAr,
        contactEn,
        contactAr,
        latitude,
        longitude,
        gMapKey,
        mapBoxKey,
        firebaseKey
    } = req.body;
    try {
        const response = await setting.create({
            logoImage,
            nameEn,
            nameAr,
            tageLineEn,
            tageLineAr,
            addressEn,
            addressAr,
            emailEn,
            emailAr,
            contactEn,
            contactAr,
            latitude,
            longitude,
            gMapKey,
            mapBoxKey,
            firebaseKey,
            status: 1
        });

        return res.status(200).json({
            success: true,
            data: {
                appInfo: response
            }
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.'
        });
        console.error(err.stack || err);
    }
};
