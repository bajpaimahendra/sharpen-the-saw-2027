const Label = require('../models/label.js');
const helper = require('../service/helper.js');

// Create and Save a new User
exports.createLabel = async (req, res) => {
    let { labelEn, labelAr, labelRef } = req.body;
    try {
        const labels = await Label.create([
            { labelRef, labelEn, labelAr, status: 1 },
        ]);

        return res.status(200).json({
            success: true,
            data: {
                label: labels,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};
// Create and Save a new User
exports.updateLabel = async (req, res) => {
    let { labelEn, labelAr, status } = req.body;

    try {
        const response = await Label.updateOne(
            {
                _id: req.body.labelId,
            },
            {
                labelEn: labelEn,
                labelAr: labelAr,
                status: status,
            }
        );
        return res
            .status(200)
            .json({ success: true, message: 'Label Updated successfully.' });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};
// Create and Save a new User
exports.getAllLabel = async (req, res) => {
    try {
        var pageNo = parseInt(req.query.pageNo);
        var size = parseInt(req.query.size);
        var query = {};
        if (pageNo < 0 || pageNo === 0) {
            return res.status(400).json({
                success: false,
                message: 'invalid page number, should start with 1',
            });
        }
        query.skip = size * (pageNo - 1);
        query.limit = size;

        Label.find({}, {}, query, function (err, data) {
            // Mongo command to fetch all data from collection.
            if (err) {
                res.status(400).json({
                    success: true,
                    message: 'Error fetching data',
                });
            } else {
                res.status(200).json({
                    success: true,
                    data: {
                        labels: data,
                    },
                });
            }
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};
