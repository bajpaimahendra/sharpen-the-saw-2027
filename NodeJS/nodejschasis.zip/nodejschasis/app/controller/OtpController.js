const Employee = require('../models/employee.js');
const OtpTrxn = require('../models/otpTrxn.js');
const helper = require('../service/helper.js');
const constant = require('../config/constant.js');
var otpGenerator = require('otp-generator');

// verify otp
exports.verifyOtp = async (req, res) => {
    try {
        if (req.body == null && body.mobile == null) {
            return res.status(400).json({ success: false, message: 'Data?!' });
        }

        // match user email
        const isOtpExist = await OtpTrxn.findOne({ mobile: req.body.mobile })
            .sort({ _id: -1 })
            .limit(1);

        if (isOtpExist == null || isOtpExist.otp != req.body.otp) {
            return res.status(400).json({
                success: false,
                message: 'OTP not found Or Incorrect OTP!',
            });
        }

        var now = new Date();
        let timeDiff = now.getTime() - isOtpExist.createdAt.getTime();
        if (timeDiff > constant.OTP_EXPIRE) {
            return res
                .status(400)
                .json({ success: false, message: 'OTP expired!' });
        }
        const isEmailExist = await Employee.findOne({
            mobile: req.body.mobile,
        });
        if (isEmailExist == null) {
            return res.status(200).json({
                success: true,
                message: 'OTP verified succesfully.',
                isUserExist: false,
            });
        }

        return res.status(200).json({
            success: true,
            isUserExist: true,
            data: {
                user: isEmailExist,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

// generate otp
exports.generateOtp = async (req, res) => {
    try {
        if (req.body == null || req.body.mobile.trim().length < 10) {
            return res
                .status(400)
                .json({ success: true, message: 'Mobile Number invalid' });
        }
        if (req.body != null && req.body.mobile != null) {
            var otp = otpGenerator.generate(4, {
                alphabets: false,
                upperCase: false,
                specialChars: false,
            });

            // helper.restClient(req.body.mobile, otp);
            const newamenties = await OtpTrxn.create({
                otp: otp,
                mobile: req.body.mobile,
                status: 1,
            });
            return res.status(200).json({
                success: true,
                message: 'OTP sent Successfully.',
                otp: otp,
            });
        }
        if (req.body != null && req.body.email != null) {
            // match user email
            const isEmailExist = await Employee.findOne({
                email: req.body.email,
            });
            if (isEmailExist == null) {
                return res
                    .status(400)
                    .json({ success: false, message: 'Email not found!' });
            }

            // send otp
            const otpTrxn = new OtpTrxn({
                email: req.body.email,
                otp: helper.generateOTP(6),
            });
            helper.otpSender(req.body.email, otpTrxn.otp);
            otpTrxn
                .save()
                .then((data) => {
                    return res.status(200).json({
                        success: true,
                        message: 'OTP sent Successfully.',
                    });
                })
                .catch((err) => {
                    res.status(500).send({
                        success: false,
                        message:
                            err.message ||
                            'Some error occurred while creating the User.',
                    });
                    console.error(err.stack || err);
                });
        }
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};
