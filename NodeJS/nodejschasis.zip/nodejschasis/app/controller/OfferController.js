const offers = require('../models/offers.js');
const helper = require('../service/helper.js');
// var path = require('path');
const excel = require('excel4node');
const { async } = require('q');

// Create and Save a new offer
// status 0 for delete/inactiove
// 1 draft, 2 publish,

exports.createOffers = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(401)
            .json({ success: false, message: 'Please login again.' });
    }

    let {
        nameEn,
        nameAr,
        descriptionEn,
        descriptionAr,
        bussinessId,
        startDate,
        endDate,
        image,
        deviceType,
        publish,
        userType,
        area,
        status,
    } = req.body;

    try {
        const newOffers = await offers.create({
            nameEn,
            nameAr,
            descriptionEn,
            descriptionAr,
            bussinessId,
            startDate,
            endDate,
            image,
            deviceType,
            publish,
            userType,
            area,
            status,
            isExplore: 0,
        });

        return res.status(201).json({
            success: true,
            data: {
                offer: newOffers,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message:
                err.message || 'Some error occurred while creating the User.',
        });
        console.error(err.stack || err);
    }
};

async function offerStat() {
    var total,
        draft,
        process,
        close = 0;

    await offers.countDocuments(
        {
            status: 2,
        },
        function (err, result) {
            process = result;
        }
    );
    await offers.countDocuments(
        {
            status: 1,
        },
        function (err, result) {
            draft = result;
        }
    );
    await offers.countDocuments(
        {
            status: 0,
        },
        function (err, result) {
            close = result;
        }
    );

    await offers.countDocuments({}, function (err, result) {
        total = result;
    });

    var response = {
        draft: draft,
        total: total,
        process: process,
        close: close,
    };
    return response;
}
exports.offerAnalysis = async (req, res) => {
    try {
        const stats = offerStat();
        stats.then(function (result) {
            return res.status(200).json({
                success: true,
                data: {
                    offerAnalysis: result,
                },
            });
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message:
                err.message || 'Some error occurred while creating the User.',
        });
        console.error(err.stack || err);
    }
};

// Create and Save a new User
exports.getAllOffers = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(400)
            .json({ success: false, message: 'Please login again.' });
    }
    try {
        // const query = { status: true, };
        var pageNo = parseInt(req.query.pageNo);
        var size = parseInt(req.query.size);
        var query = {};
        if (pageNo < 0 || pageNo === 0) {
            return res.status(400).json({
                success: false,
                message: 'invalid page number, should start with 1',
            });
        }
        query.skip = size * (pageNo - 1);
        query.limit = size;

        offers.find({}, {}, query, function (err, data) {
            // Mongo command to fetch all data from collection.
            if (err) {
                res.status(400).json({ message: 'Error fetching data' });
            } else {
                for (let i = 0; i < data.length; i++) {
                    /*console.log('Name:' + data[i].bussinessId);
                    //const isEmailExist = await Employee.findOne({ email: req.body.email });
                    //data[i].bussinessId = 'dheeraj' + i;
                    data[i].bussinessName = 'dheeraj' + i;
                    var string = data[i].area;
                    console.log(string);
                    var arr = string.split(','); // split string on comma space
                    console.log(arr);*/
                }
                const stats = offerStat();
                stats.then(function (result) {
                    return res.status(200).json({
                        success: true,
                        data: {
                            offerAnalysis: result,
                            offers: data,
                        },
                    });
                });
            }
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

// offer excel generate
exports.offerexcelgenerate = async (req, res) => {
    // return res.sendFile('/Users/marketing/Documents/slash_price.xlsx');

    // Save Note in the database
    try {
        // Create a new instance of a Workbook class
        var workbook = new excel.Workbook();

        // Add Worksheets to the workbook
        var worksheet = workbook.addWorksheet('Offersdata');
        var style = workbook.createStyle({
            font: {
                color: '#000000',
                size: 12,
            },
            numberFormat: '$#,##0.00; ($#,##0.00); -',
        });
        worksheet.cell(1, 1).string('Id').style(style);
        worksheet.cell(1, 2).string('OfferTitle').style(style);
        worksheet.cell(1, 3).string('OfferTitleAr').style(style);
        worksheet.cell(1, 4).string('DescriptionEn').style(style);
        worksheet.cell(1, 5).string('DescriptionAr').style(style);
        worksheet.cell(1, 6).string('Status').style(style);
        worksheet.cell(1, 7).string('StartDate').style(style);
        worksheet.cell(1, 8).string('EndDate').style(style);
        worksheet.cell(1, 9).string('DeviceType').style(style);
        worksheet.cell(1, 10).string('PublishedDate').style(style);
        worksheet.cell(1, 11).string('UserType').style(style);
        worksheet.cell(1, 12).string('Area').style(style);
        await offers.find().then((offer) => {
            for (var i = 0; i < offer.length; i++) {
                var rowNum = i + 2;

                worksheet.cell(rowNum, 1).string(offer[i].id).style(style);
                worksheet
                    .cell(rowNum, 2)
                    .string(offer[i].nameEn.toString())
                    .style(style);
                worksheet
                    .cell(rowNum, 3)
                    .string(offer[i].nameAr.toString())
                    .style(style);
                worksheet
                    .cell(rowNum, 4)
                    .string(offer[i].descriptionEn)
                    .style(style);
                worksheet
                    .cell(rowNum, 5)
                    .string(offer[i].descriptionAr)
                    .style(style);
                worksheet.cell(rowNum, 6).string(offer[i].Status).style(style);
                worksheet
                    .cell(rowNum, 7)
                    .string(offer[i].startDate.toString())
                    .style(style);
                worksheet
                    .cell(rowNum, 8)
                    .string(offer[i].endDate.toString())
                    .style(style);
                worksheet
                    .cell(rowNum, 9)
                    .string(offer[i].deviceType.toString())
                    .style(style);
                worksheet
                    .cell(rowNum, 10)
                    .string(offer[i].publish.toString())
                    .style(style);
                worksheet
                    .cell(rowNum, 11)
                    .string(offer[i].userType.toString())
                    .style(style);
                worksheet
                    .cell(rowNum, 12)
                    .string(offer[i].area.toString())
                    .style(style);
            }
        });
        workbook.write(`Offers.xlsx`, res);
    } catch (error) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};
