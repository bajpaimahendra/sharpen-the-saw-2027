const Ticket = require('../models/ticket.js');
const helper = require('../service/helper.js');

/*
status: open:1, Inprocess:2, close:3
Type: updateLoc:1, addloc:2, other:3
*/
// Create and Save a new User
exports.createTicket = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(401)
            .json({ success: false, message: 'Please login again.' });
    }

    let { name, description, type, assignedTo } = req.body;
    var currentDate = new Date();
    var currentMonth = currentDate.getMonth() + 1;
    try {
        const newTicket = await Ticket.create({
            name,
            description,
            type,
            assignedTo,
            status: 1,
            month: currentMonth,
        });

        return res.status(200).json({
            success: true,
            data: {
                ticktet: newTicket,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message:
                err.message || 'Some error occurred while creating the Ticket.',
        });
        console.error(err.stack || err);
    }
};

exports.getTicketAnysis = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(400)
            .json({ success: false, message: 'Please login again.' });
    }

    try {
        var open,
            process,
            updateLoc,
            addLoc,
            othrTicket,
            close = 0;

        await Ticket.countDocuments(
            {
                status: 1,
            },
            function (err, result) {
                open = result;
            }
        );

        await Ticket.countDocuments(
            {
                status: 2,
            },
            function (err, result) {
                process = result;
            }
        );

        await Ticket.countDocuments(
            {
                status: 3,
            },
            function (err, result) {
                close = result;
            }
        );

        await Ticket.countDocuments(
            {
                type: 1,
            },
            function (err, result) {
                updateLoc = result;
            }
        );

        await Ticket.countDocuments(
            {
                type: 2,
            },
            function (err, result) {
                addLoc = result;
            }
        );

        await Ticket.countDocuments(
            {
                type: 3,
            },
            function (err, result) {
                othrTicket = result;
            }
        );
        var response = {
            totalTickets: open + process + close,
            updateLoc: updateLoc,
            addLoc: addLoc,
            othrTicket: othrTicket,
            openTickets: open,
            inProcessTickets: process,
            closeTickets: close,
        };
        return res.status(200).json({
            success: true,
            data: {
                ticketAnalysis: response,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message:
                err.message || 'Some error occurred while creating the User.',
        });
        console.error(err.stack || err);
    }
};

exports.getTicketsRecordsOnMonthBasis = async (req, res) => {
    try {
        var graphTicketData = [];
        var query = {};
        var month = 0;
        for (let j = 1; j < 13; j++) {
            month = j;
            await Ticket.find(
                { month: month },
                { status: 1 },
                query,
                function (err, data) {
                    var open = 0;
                    var inProcess = 0;
                    var close = 0;
                    for (let index = 0; index < data.length; index++) {
                        if (data[index].status == 1) open++;
                        if (data[index].status == 2) inProcess++;
                        if (data[index].status == 3) close++;
                    }
                    var tickets = [open, inProcess, close];
                    graphTicketData.push({ month: month, tickets: tickets });
                }
            );
        }

        return res.status(200).json({
            success: true,
            data: {
                graphTicketData: graphTicketData,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

exports.getAllTickets = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(400)
            .json({ success: false, message: 'Please login again.' });
    }

    try {
        var pageNo = parseInt(req.query.pageNo);
        var size = parseInt(req.query.size);
        var query = {};
        if (pageNo < 0 || pageNo === 0) {
            return res.status(400).json({
                success: false,
                message: 'invalid page number, should start with 1',
            });
        }
        query.skip = size * (pageNo - 1);
        query.limit = size;

        const data = await Ticket.find({}, {}, query).sort({ _id: -1 });
        res.status(200).json({
            success: true,
            data: {
                tickets: data,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message:
                err.message || 'Some error occurred while creating the User.',
        });
        console.error(err.stack || err);
    }
};
