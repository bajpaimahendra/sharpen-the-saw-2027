const rating = require('../models/rating.js');
const users = require('../models/employee.js');
const business = require('../models/business.js');
const helper = require('../service/helper.js');
var groupBy = require('group-by');
const { findById } = require('../models/rating.js');

// Create and Save a new User
exports.createReview = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(401)
            .json({ success: false, message: 'Please login again.' });
    }

    let { userName, businessId, userId, description, score, type } = req.body;
    var currentDate = new Date();
    var currentMonth = currentDate.getMonth() + 1;
    try {
        const reviews = await rating.create([
            {
                userName,
                businessId,
                userId,
                score,
                description,
                type,
                month: currentMonth,
                status: 1,
            },
        ]);

        return res.status(200).json({
            success: true,
            data: {
                review: reviews,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

exports.getReviewByBusId = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(401)
            .json({ success: false, message: 'Please login again.' });
    }
    try {
        const reviewList = await rating
            .find({ businessId: req.params.businessId })
            .sort({ _id: -1 })
            .limit(10);

        return res.status(200).json({
            success: true,
            data: {
                reviews: reviewList,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};
exports.getReviewByUserId = async (req, res) => {
    var jsonArray = [];
    try {
        const isUsrExist = await users.findOne({ _id: req.params.userId });
        if (isUsrExist == null) throw new Error('User Not Found!');

        const reviewList = await rating
            .find({ userId: req.params.userId })
            .sort({ _id: -1 })
            .limit(10);
        for (let i = 0; i < reviewList.length; i++) {
            const businessData = await business.findOne({
                _id: reviewList[i].businessId,
            });
            if (businessData != null) {
                var response = {
                    businessId: businessData._id,
                    businessNameEn: businessData.nameEn,
                    businessNameAr: businessData.nameAr,
                    score: reviewList[i].score,
                    reviewDate: reviewList[i].createdAt,
                    description: reviewList[i].description,
                };
                jsonArray.push(response);
            }
        }

        return res.status(200).json({
            success: true,
            data: {
                user: isUsrExist,
                reviews: jsonArray,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

exports.getReviewGraphByBusinessIdonMonthBasis = async (req, res) => {
    try {
        var graphReviewData = [];
        var query = {};
        var month = 0;
        for (let j = 1; j < 13; j++) {
            month = j;
            await rating.find(
                { businessId: req.params.businessId, month: month },
                { score: 1 },
                query,
                function (err, data) {
                    var starOne = 0;
                    var starTwo = 0;
                    var starThree = 0;
                    var starFour = 0;
                    var starFive = 0;
                    for (let index = 0; index < data.length; index++) {
                        if (data[index].score == 1) starOne++;
                        if (data[index].score == 2) starTwo++;
                        if (data[index].score == 3) starThree++;
                        if (data[index].score == 4) starFour++;
                        if (data[index].score == 5) starFive++;
                    }
                    var ratings = [
                        starOne,
                        starTwo,
                        starThree,
                        starFour,
                        starFive,
                    ];
                    graphReviewData.push({ month: month, ratings: ratings });
                }
            );
        }

        return res.status(200).json({
            success: true,
            data: {
                graphReviewData: graphReviewData,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};
