const area = require('../models/area.js');
const helper = require('../service/helper.js');
var path = require('path');
const excel = require('exceljs');

exports.excelImport = (req, res) => {
    try {
        var wb = new excel.Workbook();
        console.log('hi' + req.file.path);
        var filePath = path.resolve(__dirname, 'sample.xlsx');
        console.log(req.files);
        // let sampleFile = req.files.sample.xlsx;
        wb.xlsx.readFile(filePath).then(function () {
            var sh = wb.getWorksheet('Sheet1');

            // sh.getRow(1).getCell(2).value = 32;
            wb.xlsx.writeFile('sample2.xlsx');
            // console.log('Row-3 | Cell-2 - ' + sh.getRow(3).getCell(2).value);

            console.log(sh.rowCount);
            // Get all the rows data [1st and 2nd column]
            for (i = 1; i <= sh.rowCount; i ++) {
                console.log(sh.getRow(i).getCell(1).value + ' ' + sh.getRow(i).getCell(2).value);
            }
        });
    } catch (error) {
        console.error(error.stack);
    }
};

exports.excelGenrate = (req, res) => {
    // return res.sendFile('/Users/marketing/Documents/slash_price.xlsx');

    // Save Note in the database
    try { // Create a new instance of a Workbook class
        var workbook = new excel.Workbook();

        // Add Worksheets to the workbook
        var worksheet = workbook.addWorksheet('customer');

        // WorkSheet Header
        worksheet.columns = [
            {
                header: 'Id',
                key: '_id',
                width: 10
            }, {
                header: 'Name',
                key: 'name',
                width: 30
            }, {
                header: 'City',
                key: 'city',
                width: 30
            }, {
                header: 'State',
                key: 'state',
                width: 10,
                outlineLevel: 1
            },
        ];

        area.find().then((areas) => {
            const jsonCustomers = JSON.parse(JSON.stringify(areas));
            console.log(jsonCustomers);
            worksheet.addRows(jsonCustomers);
            // workbook.write('/Users/marketing/Documents/Test123.xlsx');
            console.log('Excel generated succefully');

            /*  res.setHeader(
                'Content-Type',
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            );
            res.setHeader(
                'Content-Disposition',
                'attachment; filename=' + 'tutorials.xlsx'
            );*/
            // res.sendFile('/Users/marketing/Documents/slash_price.xlsx');
            res.attachment('tutorials.xlsx');
            console.log(res.get('Content-Disposition'));
            return workbook.xlsx.write(res).then(function () {
                res.status(200).end();
            });
        });
    } catch (error) {
        console.error(error.stack);
    }
};

// Create and Save a new User
exports.createArea = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (! result) {
        return res.status(401).json({success: false, message: 'Please login again.'});
    }

    let {nameEn, nameAr, country} = req.body;
    try {
        const newArea = await area.create({nameEn, nameAr, country, status: 1});
        return res.status(201).json({
            success: true,
            data: {
                area: newArea
            }
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.'
        });
        console.error(err.stack || err);
    }
};

// Create and Save a new User
exports.updateArea = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (! result) {
        return res.status(401).json({success: false, message: 'Please login again.'});
    }

    let {nameEn, nameAr, country, status} = req.body;

    try {
        const response = await area.updateOne({
            _id: req.body.areaId
        }, {
            nameEn: nameEn,
            nameAr: nameAr,
            country: country,
            status: status
        });
        return res.status(200).json({success: true, message: 'Area Updated successfully.'});
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.'
        });
        console.error(err.stack || err);
    }
};

// Create and Save a new User
exports.getAllArea = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (! result) {
        return res.status(401).json({success: false, message: 'Please login again.'});
    }
    try { // const query = { status: true, };
        var pageNo = parseInt(req.query.pageNo);
        var size = parseInt(req.query.size);
        var query = {};
        if (pageNo < 0 || pageNo === 0) {
            return res.status(400).json({success: false, message: 'invalid page number, should start with 1'});
        }
        query.skip = size * (pageNo - 1);
        query.limit = size;

        area.find({}, {}, query, function (err, data) { // Mongo command to fetch all data from collection.
            if (err) {
                res.status(400).json({message: 'Error fetching data'});
            } else {
                res.status(200).json({
                    success: true,
                    data: {
                        area: data
                    }
                });
            }
        });

        /* area.find(query).then((areas) => {
            if (areas.length > 0) {
                return res.status(200).json({ areas: areas });
            } else {
                res.status(400).send({
                    message: "No Area found'!.",
                });
            }
        });*/
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.'
        });
        console.error(err.stack || err);
    }
};
