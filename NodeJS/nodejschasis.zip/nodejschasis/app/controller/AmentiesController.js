const amenties = require('../models/amenties.js');
const helper = require('../service/helper.js');

// Create and Save a new User
exports.createAmenties = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (! result) {
        return res.status(401).json({success: false, message: 'Please login again.'});
    }

    let {nameEn, nameAr, image} = req.body;

    try {
        const newamenties = await amenties.create({nameEn, nameAr, image, status: 1});

        return res.status(201).json({
            success: true,
            data: {
                amentie: newamenties
            }
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Some error occurred while creating the User.'
        });
        console.error(err.stack || err);
    }
};

// Create and Save a new User
exports.updateAmenties = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (! result) {
        return res.status(401).json({success: false, message: 'Please login again.'});
    }

    let {nameEn, nameAr, image, status} = req.body;

    try {
        const response = await amenties.updateOne({
            _id: req.body.amentiesId
        }, {
            nameEn: nameEn,
            nameAr: nameAr,
            image: image,
            status: status
        });
        return res.status(200).json({success: true, message: 'Amenties Updated successfully.'});
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.'
        });
        console.error(err.stack || err);
    }
};

// Create and Save a new User
exports.getAllAmenties = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (! result) {
        return res.status(401).json({success: false, message: 'Please login again.'});
    }
    try { // const query = { status: true, };
        var pageNo = parseInt(req.query.pageNo);
        var size = parseInt(req.query.size);
        var query = {};
        if (pageNo < 0 || pageNo === 0) {
            return res.status(400).json({message: 'invalid page number, should start with 1'});
        }
        query.skip = size * (pageNo - 1);
        query.limit = size;

        amenties.find({}, {}, query, function (err, data) { // Mongo command to fetch all data from collection.
            if (err) {
                res.status(400).json({message: 'Error fetching data'});
            } else {
                res.status(200).json({
                    success: true,
                    data: {
                        amenties: data
                    }
                });
            }
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.'
        });
        console.error(err.stack || err);
    }
};
