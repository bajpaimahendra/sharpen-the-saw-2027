const cmsPage = require('../models/cmsPage.js');
const helper = require('../service/helper.js');

// Create and Save a new User
exports.createCmsPage = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (! result) {
        return res.status(401).json({message: 'Please login again.'});
    }

    let {
        nameEn,
        nameAr,
        metaData,
        metakeywords,
        metaDescription,
        slug,
        desriptionEn,
        desriptionAr
    } = req.body;

    try {
        const newCMsPage = await cmsPage.create({
            nameEn,
            nameAr,
            metaData,
            metakeywords,
            metaDescription,
            slug,
            desriptionEn,
            desriptionAr,
            status: 1
        });
        return res.status(201).json({
            success: true,
            data: {
                cmsPage: newCMsPage
            }
        });
    } catch (err) {
        res.status(500).send({
            message: err.message || 'Something went wrong!.'
        });
        console.error(err.stack || err);
    }
};

// Create and Save a new User
exports.updateCmsPage = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (! result) {
        return res.status(401).json({message: 'Please login again.'});
    }

    let {
        nameEn,
        nameAr,
        metaData,
        metakeywords,
        metaDescription,
        slug,
        desriptionEn,
        desriptionAr,
        status
    } = req.body;

    try {
        const response = await cmsPage.updateOne({
            _id: req.body.cmsId
        }, {
            nameEn: nameEn,
            nameAr: nameAr,
            metaData: metaData,
            metakeywords: metakeywords,
            metaDescription: metaDescription,
            slug: slug,
            desriptionEn: desriptionEn,
            desriptionAr: desriptionAr,
            status: status
        });
        return res.status(200).json({success: true, message: 'Cms data Updated successfully.'});
    } catch (err) {
        res.status(500).send({
            message: err.message || 'Something went wrong!.'
        });
        console.error(err.stack || err);
    }
};

// Create and Save a new User
exports.getAllCms = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (! result) {
        return res.status(401).json({success: false, message: 'Please login again.'});
    }
    try {
        var pageNo = parseInt(req.query.pageNo);
        var size = parseInt(req.query.size);
        var query = {};
        if (pageNo < 0 || pageNo === 0) {
            return res.status(400).json({success: false, message: 'invalid page number, should start with 1'});
        }
        query.skip = size * (pageNo - 1);
        query.limit = size;

        cmsPage.find({}, {}, query, function (err, data) { // Mongo command to fetch all data from collection.
            if (err) {
                res.status(400).json({success: false, message: 'Error fetching data'});
            } else {
                res.status(200).json({
                    success: true,
                    data: {
                        cmsPages: data
                    }
                });
            }
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.'
        });
        console.error(err.stack || err);
    }
};
