const images = require('../models/images.js');
const package = require('../models/packages.js');
const helper = require('../service/helper.js');
const constant = require('../config/constant.js');
const bussiness = require('../models/business.js');

// Create and Save a new User
exports.createImages = async (req, res) => {
    try {
        const authtoken = req.headers['token'];
        let result = await helper.validateToken(authtoken);

        if (!result) {
            return res
                .status(401)
                .json({ success: false, message: 'Please login again.' });
        }

        let { businessId, uploadBy, imagePath } = req.body;
        const businessInfo = await bussiness.findOne({ _id: businessId });
        if (businessInfo == null) throw new Error('Business Not found');

        const packageInfo = await package.findOne({
            _id: businessInfo.packageId,
        });
        var imageSize = 0;
        await images.countDocuments(
            {
                businessId: businessId,
            },
            function (err, result) {
                imageSize = result;
            }
        );

        if (packageInfo == null) throw new Error('Package Not found');

        if (packageInfo.numberofbusinessimageupload == imageSize)
            throw new Error('Limit Exceeds.');

        const newimages = await images.create({
            businessId,
            uploadBy,
            imagePath,
            status: constant.ACTIVE,
        });

        return res.status(201).json({
            success: true,
            data: {
                image: newimages,
            },
        });
    } catch (err) {
        res.status(400).send({
            success: false,
            message:
                err.message || 'Some error occurred while uploading the Image.',
        });
        console.error(err.stack || err);
    }
};

exports.getAllImagesById = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(401)
            .json({ success: false, message: 'Please login again.' });
    }
    try {
        const imagesList = await images.find({
            businessId: req.params.businessId,
        });
        return res.status(200).json({
            success: true,
            data: {
                iamges: imagesList,
            },
        });
    } catch (err) {
        res.status(400).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};
