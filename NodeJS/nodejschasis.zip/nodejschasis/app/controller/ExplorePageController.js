const explorePage = require('../models/explorePage.js');
const offer = require('../models/offers.js');
const category = require('../models/category.js');
const event = require('../models/events.js');
const package = require('../models/packages.js');
const business = require('../models/business.js');
const helper = require('../service/helper.js');

exports.createExplorer = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(401)
            .json({ success: false, message: 'Please login again.' });
    }
    let { offers, events, packages, ads, topPics, categories } = req.body;
    try {
        const filter = { isExplore: 1 };
        const updateDoc = {
            $set: {
                isExplore: 0,
            },
        };
        await category.updateMany(filter, updateDoc);
        categories.forEach(async (element) => {
            await category.updateOne(
                {
                    _id: element,
                },
                {
                    isExplore: 1,
                }
            );
        });
        await offer.updateMany(filter, updateDoc);
        offers.forEach(async (element) => {
            await offer.updateOne(
                {
                    _id: element,
                },
                {
                    isExplore: 1,
                }
            );
        });
        await event.updateMany(filter, updateDoc);
        events.forEach(async (element) => {
            await event.updateOne(
                {
                    _id: element,
                },
                {
                    isExplore: 1,
                }
            );
        });
        await package.updateMany(filter, updateDoc);
        packages.forEach(async (element) => {
            await package.updateOne(
                {
                    _id: element,
                },
                {
                    isExplore: 1,
                }
            );
        });
        await business.updateMany(filter, updateDoc);
        topPics.forEach(async (element) => {
            await business.updateOne(
                {
                    _id: element,
                },
                {
                    isExplore: 1,
                }
            );
        });
        return res.status(200).json({
            success: true,
            data: {
                explorePage: 'NewexplorePage',
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

// Create and Save a new User
exports.getExplorer = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(400)
            .json({ success: false, message: 'Please login again.' });
    }
    try {
        const categorys = await category.find(
            {
                status: 1,
                isExplore: 1,
            },
            {
                _id: 1,
                nameEn: 1,
                nameAr: 1,
            }
        );
        const offers = await offer.find(
            {
                status: 2,
                isExplore: 1,
            },
            {
                _id: 1,
                nameEn: 1,
                nameAr: 1,
            }
        );

        const events = await event.find(
            {
                status: 2,
                isExplore: 1,
            },
            {
                _id: 1,
                nameEn: 1,
                nameAr: 1,
            }
        );
        const packages = await package.find(
            {
                status: 1,
                isExplore: 1,
            },
            {
                _id: 1,
                nameEn: 1,
                nameAr: 1,
            }
        );
        const businesses = await business.find(
            {
                status: 1,
                isExplore: 1,
            },
            {
                _id: 1,
                nameEn: 1,
                nameAr: 1,
            }
        );
        return res.status(200).json({
            categories: categorys,
            offers: offers,
            events: events,
            packages: packages,
            businesses: businesses,
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};
