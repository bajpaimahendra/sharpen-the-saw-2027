const Employee = require('../models/employee.js');
const deviceInfo = require('../models/deviceInfo.js');
const userAddress = require('../models/userAddress.js');
const location = require('../models/location.js');
const OtpTrxn = require('../models/otpTrxn.js');
const helper = require('../service/helper.js');
const constant = require('../config/constant.js');
const excel = require('excel4node');
const { async } = require('q');

const schedule = require('node-schedule');
const employee = require('../models/employee.js');

const job = schedule.scheduleJob('0 0/10 * * * *', function () {
    console.log('User Cron Strated:' + new Date());
});

// type: 1 for guest
// 2 for register

// Create and Save a new User Address
exports.createDeviceInfo = async (req, res) => {
    try {
        // find user
        const isUsrExist = await Employee.findOne({ _id: req.body.userId });
        if (isUsrExist == null) throw new Error('User Not Found!');

        let {
            userId,
            type,
            model,
            imei,
            deviceId,
            mapView,
            lang,
            navigation,
            navAlert,
            locAlert,
            offerEventAlert,
        } = req.body;

        const response = await deviceInfo.create({
            userId,
            type,
            model,
            imei,
            deviceId,
            token: helper.checkSumOnPwd(helper.randomString(8)),
            mapView,
            lang,
            navigation,
            navAlert,
            locAlert,
            offerEventAlert,
        });
        res.status(200).send({
            success: true,
            deviceInfo: response,
        });
    } catch (err) {
        res.status(400).send({
            success: false,
            message:
                err.message ||
                'Some error occurred while creating the User DeviceInfo.',
        });
        console.error(err.stack || err);
    }
};

// Get Device Info
exports.getDeviceInfoByUser = async (req, res) => {
    try {
        // find user
        const isUsrExist = await Employee.findOne({ _id: req.query.userId });
        if (isUsrExist == null) throw new Error('User Not Found!');

        if (req.query.userId == null || req.query.deviceId == null)
            throw new Error('Invalid UserId or DeviceId Found!');

        const deviceInfoList = await deviceInfo.find({
            userId: req.query.userId,
            deviceId: req.query.deviceId,
        });
        res.status(200).send({
            success: true,
            deviceInfos: deviceInfoList,
        });
    } catch (err) {
        res.status(400).send({
            success: false,
            message:
                err.message ||
                'Some error occurred while getting the User Address.',
        });
        console.error(err.stack || err);
    }
};

// Create and Save a new User Address
exports.getUserAddress = async (req, res) => {
    try {
        const userAddressList = await userAddress.find({
            userId: req.params.userId,
        });
        var response = [];
        for (let i = 0; i < userAddressList.length; i++) {
            const locData = await location.findOne({
                _id: userAddressList[i].locationId,
            });
            response.push({
                userAddress: userAddressList[i],
                location: locData,
            });
        }

        res.status(200).send({
            success: true,
            addresses: response,
        });
    } catch (err) {
        res.status(400).send({
            success: false,
            message:
                err.message ||
                'Some error occurred while getting the User Address.',
        });
        console.error(err.stack || err);
    }
};

// Create and Save a new User Address
exports.addUserAddress = async (req, res) => {
    try {
        // match username
        const isUsrExist = await Employee.findOne({ _id: req.body.userId });
        if (isUsrExist == null) throw new Error('User Not Found!');

        let { userId, locationId, landMark } = req.body;
        var type = req.body.type;
        type = type.toUpperCase().trim();
        const isUserTypeExist = await userAddress.find({
            userId: userId,
            type: type,
        });
        if (isUserTypeExist.length > 0) {
            var response = await userAddress.updateOne(
                {
                    userId: userId,
                },
                {
                    locationId: locationId,
                    landMark: landMark,
                }
            );
            if (response.n == 1) {
                return res.status(200).json({
                    success: true,
                    message: 'User Address Update Successfully',
                });
            }
        }
        if (isUserTypeExist.length == 0) {
            const newUserAddress = await userAddress.create({
                userId,
                locationId,
                landMark,
                type,
                status: constant.ACTIVE,
            });
            return res.status(201).json({
                success: true,
                data: {
                    userAddress: newUserAddress,
                },
            });
        }
    } catch (err) {
        res.status(500).send({
            success: false,
            message:
                err.message || 'Some error occurred while creating the User.',
        });
        console.error(err.stack || err);
    }
};

// Create and Save a new User
exports.signUp = async (req, res) => {
    try {
        // match user email
        const isEmailExist = await Employee.findOne({
            email: req.body.email,
        });
        if (isEmailExist != null) {
            throw new Error('Email already exist!');
        }
        if (!(req.body.type == 1 || req.body.type == 2)) {
            // match username
            const isUsrExist = await Employee.findOne({
                username: req.body.username,
            });
            if (isUsrExist != null) {
                throw new Error('Username already exist!');
            }
        }

        // match username
        const isContactExist = await Employee.findOne({
            mobile: req.body.mobile,
        });
        if (isContactExist != null) {
            throw new Error('Mobile Number already exist!');
        }
        let {
            firstName,
            lastName,
            email,
            username,
            gender,
            type,
            mobile,
            createdBy,
        } = req.body;
        if (!(type == 1 || type == 2)) {
            var pwd = helper.checkSumOnPwd(req.body.pwd);
        }

        const newUser = await Employee.create({
            firstName,
            lastName,
            email,
            username,
            gender,
            pwd,
            type,
            mobile,
            createdBy,
            token: helper.checkSumOnPwd(helper.randomString(8)),
            status: 1,
        });
        return res.status(200).json({
            success: true,
            data: {
                user: newUser,
            },
        });
    } catch (err) {
        res.status(400).send({
            success: false,
            message:
                err.message || 'Some error occurred while creating the User.',
        });
        console.error(err.stack || err);
    }
};

// GET profile
exports.getProfile = async (req, res) => {
    try {
        const isUserLogin = await Employee.findOne({ _id: req.params.userId });
        return res.status(200).json({
            success: true,
            data: {
                user: isUserLogin,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

// GET profile
exports.getProfileForLatestUser = async (req, res) => {
    var pageNo = parseInt(req.query.pageNo);
    var size = parseInt(req.query.size);
    var query = {};
    if (pageNo < 0 || pageNo === 0) {
        return res.status(400).json({
            success: false,
            message: 'invalid page number or type, should start with 1',
        });
    }
    query.skip = size * (pageNo - 1);
    query.limit = size;
    var dataArray = [];

    Employee.find({}, {}, query, function (err, data) {
        // Mongo command to fetch all data from collection.
        if (err) {
            res.status(400).json({
                message: 'Error fetching data',
            });
        } else {
            for (let i = data.length; i > 0; i--) {
                var response = {
                    userId: data[i - 1].id,
                    createdAt: data[i - 1].createdAt,
                    fullName:
                        data[i - 1].firstName + ' ' + data[i - 1].lastName,
                    device: 'Nokia',
                    search: '10',
                };
                dataArray.push(response);
            }

            res.status(200).json({
                success: true,
                data: {
                    latestUsers: dataArray,
                },
            });
        }
    });
};

// GET user stat
exports.getUserStats = async (req, res) => {
    var iphone,
        android,
        web,
        register,
        guest = 0;

    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(400)
            .json({ success: false, message: 'Please login again.' });
    }
    var types = ['1', '2'];
    await Employee.countDocuments(
        {
            type: '1',
        },
        function (err, result) {
            guest = result;
        }
    );
    await Employee.countDocuments(
        {
            type: '2',
        },
        function (err, result) {
            register = result;
        }
    );
    await Employee.countDocuments(
        {
            type: {
                $in: types,
            },
            createdBy: 'android',
        },
        function (err, result) {
            android = result;
        }
    );
    await Employee.countDocuments(
        {
            type: {
                $in: types,
            },
            createdBy: 'iphone',
        },
        function (err, result) {
            iphone = result;
        }
    );
    await Employee.countDocuments(
        {
            type: {
                $in: types,
            },
            createdBy: 'web',
        },
        function (err, result) {
            web = result;
        }
    );
    var response = {
        iphone: iphone,
        android: android,
        web: web,
        totalApp: iphone + android + web,
        guest: guest,
        register: register,
    };
    return res.status(200).json({
        success: true,
        data: {
            userAnalysis: response,
        },
    });
};

// GET profile by Type
/*
req.param.type: 1- Apllication user and db type: 1,2 for Register and Unregister
req.param.type: 2- Dwr Internal user 
*/
exports.getUsersByType = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(400)
            .json({ success: false, message: 'Please login again.' });
    }

    try {
        var type = parseInt(req.query.type);

        var pageNo = parseInt(req.query.pageNo);
        var size = parseInt(req.query.size);
        var query = {};
        if (type == null && (pageNo < 0 || pageNo === 0)) {
            return res.status(400).json({
                success: false,
                message: 'invalid page number or type, should start with 1',
            });
        }
        query.skip = size * (pageNo - 1);
        query.limit = size;
        var types = ['1', '2'];
        if (type == 1) {
            Employee.find(
                {
                    type: {
                        $in: types,
                    },
                },
                {},
                query,
                function (err, data) {
                    // Mongo command to fetch all data from collection.
                    if (err) {
                        res.status(400).json({
                            message: 'Error fetching data',
                        });
                    } else {
                        res.status(200).json({
                            success: true,
                            data: {
                                users: data,
                            },
                        });
                    }
                }
            );
        } else {
            Employee.find(
                {
                    type: {
                        $nin: types,
                    },
                },
                {},
                query,
                function (err, data) {
                    // Mongo command to fetch all data from collection.
                    if (err) {
                        res.status(400).json({
                            success: false,
                            message: 'Error fetching data',
                        });
                    } else {
                        res.status(200).json({
                            success: true,
                            data: {
                                users: data,
                            },
                        });
                    }
                }
            );
        }
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

// Logout Profile
exports.logout = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(400)
            .json({ success: false, message: 'Please login again.' });
    }
    var response = await Employee.updateOne(
        {
            token: authtoken,
        },
        {
            token: helper.checkSumOnPwd(helper.randomString(8)),
        }
    );
    if (response.n == 1) {
        return res
            .status(200)
            .json({ success: true, message: 'Logout Successfully.' });
    }
    return res
        .status(400)
        .json({ success: false, message: 'Please login again.' });
};

// reset password
exports.resetPwd = async (req, res) => {
    // match user email
    const isEmailExist = await Employee.findOne({ email: req.body.email });
    if (isEmailExist == null) {
        return res
            .status(400)
            .json({ success: false, message: 'Email not found!' });
    }

    // match user email
    const isOtpExist = await OtpTrxn.findOne({ email: req.body.email })
        .sort({ _id: -1 })
        .limit(1);

    if (isOtpExist == null || isOtpExist.otp != req.body.otp) {
        return res.status(400).json({
            success: false,
            message: 'OTP not found Or Incorrect OTP!',
        });
    }

    var now = new Date();
    let timeDiff = now.getTime() - isOtpExist.createdAt.getTime();
    if (timeDiff > constant.OTP_EXPIRE) {
        return res
            .status(400)
            .json({ success: false, message: 'OTP expired!' });
    }

    const encrypPwd = helper.checkSumOnPwd(req.body.newPwd);
    const response = await Employee.updateOne(
        {
            _id: isEmailExist._id,
        },
        { pwd: encrypPwd }
    );
    return res
        .status(200)
        .json({ success: true, message: 'Password Change Successfully.' });
};

// update
exports.updateProfile = async (req, res) => {
    try {
        let { firstName, lastName, gender, mobile, image } = req.body;

        const userId = req.body.userId;
        const isUserExist = await Employee.findOne({ _id: userId });
        if (isUserExist == null) throw new Error('User not found!');
        if (!(isUserExist.mobile == mobile)) {
            const isMobilExist = await Employee.findOne({ mobile: mobile });
            if (isMobilExist != null) throw new Error('Mobile already exist!');
        }
        const response = await Employee.updateOne(
            {
                _id: userId,
            },
            {
                firstName: firstName,
                lastName: lastName,
                gender: gender,
                mobile: mobile,
                image: image,
            }
        );
        return res
            .status(200)
            .json({ success: true, message: 'Profile Updated successfully.' });
    } catch (err) {
        res.status(400).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

// login
exports.login = async (req, res) => {
    // match user email
    if (req.body.email != null) {
        const isEmailExist = await Employee.findOne({ email: req.body.email });
        if (isEmailExist == null) {
            return res
                .status(400)
                .json({ success: false, message: 'Email not found!' });
        } else {
            const encrypPwd = helper.checkSumOnPwd(req.body.pwd);
            if (isEmailExist.pwd == encrypPwd) {
                var response = await Employee.updateOne(
                    {
                        _id: isEmailExist._id,
                    },
                    { updatedAt: Date.now }
                );
                response = await Employee.findOne({ _id: isEmailExist._id });
                return res.status(200).json({
                    success: true,
                    data: {
                        user: response,
                    },
                });
            } else {
                return res
                    .status(200)
                    .json({ success: false, message: 'Incorrect Password' });
            }
        }
    }

    // match username
    if (req.body.username != null) {
        const isUsrExist = await Employee.findOne({
            username: req.body.username,
        });
        if (isUsrExist == null) {
            return res
                .status(400)
                .json({ success: false, message: 'Username not found!' });
        } else {
            const encrypPwd = helper.checkSumOnPwd(req.body.pwd);
            if (isUsrExist.pwd == encrypPwd) {
                var response = await Employee.updateOne(
                    {
                        _id: isUsrExist._id,
                    },
                    { updatedAt: Date.now }
                );
                response = await Employee.findOne({ _id: isUsrExist._id });

                return res.status(200).json({
                    success: true,
                    data: {
                        user: response,
                    },
                });
            } else {
                return res
                    .status(200)
                    .json({ success: false, message: 'Incorrect Password' });
            }
        }
    }
};

// user export
exports.userexcelGenrate = async (req, res) => {
    try {
        // Create a new instance of a Workbook class
        var workbook = new excel.Workbook();

        // Add Worksheets to the workbook
        var worksheet = workbook.addWorksheet('User Data');

        // Create a reusable style
        var style = workbook.createStyle({
            font: {
                color: '#000000',
                size: 12,
            },
            numberFormat: '$#,##0.00; ($#,##0.00); -',
        });

        worksheet.cell(1, 1).string('Id').style(style);
        worksheet.cell(1, 2).string('Name').style(style);
        worksheet.cell(1, 3).string('Email').style(style);
        worksheet.cell(1, 4).string('Gender').style(style);
        worksheet.cell(1, 5).string('Status').style(style);
        worksheet.cell(1, 6).string('Phone').style(style);
        worksheet.cell(1, 7).string('Type').style(style);
        worksheet.cell(1, 8).string('Governorates').style(style);
        worksheet.cell(1, 9).string('Created_By').style(style);

        await Employee.find().then((users) => {
            for (var i = 0; i < users.length; i++) {
                var rowNum = i + 2;
                worksheet.cell(rowNum, 1).string(users[i].id).style(style);
                worksheet
                    .cell(rowNum, 2)
                    .string(
                        users[i].firstName.toString() +
                            ' ' +
                            users[i].lastName.toString()
                    )
                    .style(style);
                worksheet
                    .cell(rowNum, 3)
                    .string(users[i].email.toString())
                    .style(style);
                worksheet
                    .cell(rowNum, 4)
                    .string(users[i].gender.toString())
                    .style(style);

                var status = null;
                if (users[i].status == 1) {
                    status = 'Active';
                }

                worksheet.cell(rowNum, 5).string(status).style(style);
                worksheet.cell(rowNum, 6).string(users[i].phone).style(style);
                worksheet
                    .cell(rowNum, 7)
                    .string(users[i].type.toString())
                    .style(style);
                worksheet
                    .cell(rowNum, 8)
                    .string(users[i].governorates)
                    .style(style);
                worksheet
                    .cell(rowNum, 9)
                    .string(users[i].createdBy)
                    .style(style);
            }
        });
        workbook.write(`User.xlsx`, res);
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};
