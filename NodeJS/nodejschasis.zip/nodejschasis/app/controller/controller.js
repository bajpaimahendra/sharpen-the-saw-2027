// const db = require('../models');
const helper = require('../service/helper.js');
// var Usr = require('../models/nativeQury.js');
const config = require('../config/constant.js');
const Employee = require('../models/employee.js');
// const Tutorial = db.tutorials;
// const Op = db.Sequelize.Op;
const excel = require('exceljs');
var fs = require('fs'),
    request = require('request');
const {isNullOrUndefined} = require('util');

// Create and Save a new User
exports.signUp = (req, res) => {
    Employee.findOne({
        username: req.body.username
    }, function (err, docs) {
        if (err) {
            console.log(err);
        } else {
            if (docs != null) {
                return res.status(400).send({message: 'Username already exist!'});
            }
        }
    });

    Employee.findOne({
        email: req.body.email
    }, function (err, docs) {
        if (err) {
            console.log(err);
        } else {
            if (docs != null) {
                return res.status(400).send({message: 'Email already exist!'});
            }
        }
    });

    // Create a Note
    const employee = new Employee({
        name: req.body.name,
        email: req.body.email,
        username: req.body.username,
        pwd: helper.checkSumOnPwd(req.body.pwd),
        type: req.body.type
    });

    employee.save().then((data) => {
        res.send(data);
    }).catch((err) => {
        res.status(500).send({
            message: err.message || 'Some error occurred while creating the User.'
        });
        console.error(err.stack || err);
    });
};

// Create and Save a new Tutorial
exports.create = (req, res) => {};

// download image from url
exports.downloadImage = async (req, res) => {
    try { /*const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
      return res
        .status(400)
        .json({ message: "Please login again." });
    }*/

        var fileName = req.params.name;
        console.log('Downloading:' + config.FILE_PATH + fileName);

        var files = fs.createReadStream(config.FILE_PATH + fileName);
        res.writeHead(200, {
            'Content-disposition': 'attachment; filename=' + fileName
        }); // here you can add more headers
        files.pipe(res);
        // res.download(config.FILE_PATH + fileName);
        // res.attachment(config.FILE_PATH + fileName);
        /*res.download(config.FILE_PATH + fileName, function (err) {
      if (err) {
        console.log(err)
      } else {
        // decrement a download credit, etc.
      }
    })*/
    } catch (err) {
        res.status(500).send({
            message: err.message || 'Some error occurred while creating the User.'
        });
        console.error(err.stack || err);
    }
};

// upload a new image by converting base64
exports.uploadImage = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (! result) {
        return res.status(400).json({message: 'Please login again.'});
    }

    let base64Image = req.body.image;
    let imageName = req.body.name;
    imageName = imageName + '_' + helper.randomString(4);
    let imageType = req.body.type;
    if (imageType == null) {
        imageType = '.jpeg';
    }
    try {
        var downloadUrl = config.APPLICATION_PATH + imageName + imageType;

        require('fs').writeFile(config.FILE_PATH + imageName + imageType, base64Image, {
            encoding: 'base64'
        }, function (err) {
            // var response = helper.restClient()
            // console.log('Res:' + response);
            res.status(200).send({
                message: 'Download image from this url :: ' + downloadUrl,
                success: true
            });
        });
    } catch (err) {
        res.status(500).send({
            message: err.message || 'Some error occurred while creating the User.'
        });
        console.error(err.stack || err);
    }
};

exports.read_a_task = function (req, res) {
    helper.restClient();
    Usr.getTaskById(req.params.id, function (err, task) {
        if (err) 
            res.send(err);
        
        res.json(task);
    });
};

// Retrieve all Tutorials from the database.
exports.findAll = (req, res) => {};

// Find a single Tutorial with an id
exports.findOne = (req, res) => {};

// Update a Tutorial by the id in the request
exports.update = (req, res) => {};

// Delete a Tutorial with the specified id in the request
exports.delete = (req, res) => {};

// Delete all Tutorials from the database.
exports.deleteAll = (req, res) => {};

// Find all published Tutorials
exports.findAllPublished = (req, res) => {};

/*exports.findAll = (req, res) => {
    Tutorial.findAll()
        .then((data) => {
            console.log(data);
            res.setHeader('Content-Type', 'application/json');
            res.status(200).send(data);
            console.log('Calling Mailer');

            helper.sendMailer();
        })
        .catch((err) => {
            res.setHeader('Content-Type', 'application/json');
            res.status(500).send({
                message: 'Error retrieving Tutorial with id=',
            });
        });
};

exports.findOne = (req, res) => {
    console.log('inside findone_' + req.id);
    Tutorial.findByPk(req.params.noteId)
        .then((data) => {
            console.log(data);
            res.send(data);
        })
        .catch((err) => {
            res.status(500).send({
                message: 'Error retrieving Tutorial with id=' + id,
            });
        });
};

exports.create = (req, res) => {
    // Validate request
    if (!req.body.fullName) {
        res.status(400).send({
            message: 'Content can not be empty!',
        });
        return;
    }

    // Create a Tutorial
    const tutorial = {
        fullName: req.body.fullName,
        email: req.body.email,
        status: req.body.status ? req.body.published : true,
    };

    // Save Tutorial in the database
    Tutorial.create(tutorial)
        .then((data) => {
            res.send(data);
        })
        .catch((err) => {
            res.status(500).send({
                message:
                    err.message ||
                    'Some error occurred while creating the User.',
            });
        });
};
*/
