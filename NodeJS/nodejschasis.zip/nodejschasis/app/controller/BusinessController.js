const bussiness = require('../models/business.js');
const categoryController = require('../controller/CategortController');
const category = require('../models/category.js');
const helper = require('../service/helper.js');
const rating = require('../models/rating.js');
const constant = require('../config/constant.js');
const { async } = require('q');
var path = require('path');
const excel = require('excel4node');

const { getHashOfPassword } = require('excel4node/distribution/lib/utils');

//status 1 for request
// 2 for approved, 0 for block
// Create and Save a new User
exports.createBussiness = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res.status(401).json({ message: 'Please login again.' });
    }

    let {
        nameEn,
        nameAr,
        categoryId,
        addressLine1,
        addressLine2,
        areaId,
        mobile,
        email,
        logo,
        workingHours,
        primaryEmail,
        altEmail,
        primaryContact,
        altContact,
        packageId,
        latitude,
        longitude,
        fbLink,
        InstLink,
        twitLink,
        linkedinLink,
        iosLink,
        andLink,
        website,
        createdBy,
    } = req.body;

    try {
        const newBussiness = await bussiness.create({
            nameEn,
            nameAr,
            categoryId,
            addressLine1,
            addressLine2,
            areaId,
            mobile,
            email,
            logo,
            workingHours,
            primaryEmail,
            altEmail,
            primaryContact,
            altContact,
            packageId,
            latitude,
            longitude,
            fbLink,
            InstLink,
            twitLink,
            linkedinLink,
            iosLink,
            andLink,
            website,
            createdBy,
            status: 1,
        });
        return res.status(201).json({
            success: true,
            data: {
                bussiness: newBussiness,
            },
        });
    } catch (err) {
        res.status(500).send({
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

exports.getNearBy = async (req, res) => {
    try {
        var jsonArray = [];
        if (
            req.body.lat == null ||
            req.body.long == null ||
            req.body.userId == null
        )
            throw new Error('Invalid Latitude or Longitude or UserId found!');

        await bussiness.find(
            {
                status: 2,
            },
            {
                latitude: 1,
                longitude: 1,
                nameEn: 1,
                nameAr: 1,
                logo: 1,
                addressLine1: 1,
                addressLine2: 1,
            },
            {},
            async function (err, data) {
                for (let i = 0; i < data.length; i++) {
                    let distance = await helper.distance(
                        req.body.lat,
                        req.body.long,
                        data[i].latitude,
                        data[i].longitude,
                        'K'
                    );
                    if (distance <= constant.DISTANCE_RANGE) {
                        var response = {
                            businessId: data[i].id,
                            logo: data[i].logo,
                            nameEn: data[i].nameEn,
                            nameAr: data[i].nameAr,
                            addressLine1: data[i].addressLine1,
                            addressLine2: data[i].addressLine2,
                            distance: distance.toFixed(2) + ' KM',
                            isFav: true,
                            score: 4,
                            review: 100,
                        };
                        jsonArray.push(response);
                    }
                }
            }
        );

        const categorys = await helper.allCatByUser(req.body.userId);
        return res.status(200).json({
            success: true,
            data: {
                categories: categorys,
                business: jsonArray,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

// GET profile
exports.getLatestBusiness = async (req, res) => {
    var pageNo = parseInt(req.query.pageNo);
    var size = parseInt(req.query.size);
    var query = {};
    if (pageNo < 0 || pageNo === 0) {
        return res.status(400).json({
            success: false,
            message: 'invalid page number or type, should start with 1',
        });
    }
    query.skip = size * (pageNo - 1);
    query.limit = size;
    var dataArray = [];

    bussiness.find({}, {}, query, function (err, data) {
        // Mongo command to fetch all data from collection.
        if (err) {
            res.status(400).json({
                message: 'Error fetching data',
            });
        } else {
            for (let i = data.length; i > 0; i--) {
                var response = {
                    businessId: data[i - 1].id,
                    name: data[i - 1].nameEn,
                    createdAt: data[i - 1].createdAt,
                    requestedBy: data[i - 1].createdBy,
                    status: data[i - 1].status,
                };
                dataArray.push(response);
            }

            res.status(200).json({
                success: true,
                data: {
                    latestBusiness: dataArray,
                },
            });
        }
    });
};
// Create and Save a new User
exports.updatePackageInBussiness = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res.status(401).json({ message: 'Please login again.' });
    }

    let { packageId } = req.body;

    if (packageId == null && req.body.bussinessId == null) {
        return res
            .status(401)
            .json({ message: 'PackageId or BussinessId should not be null.' });
    }

    try {
        const response = await bussiness.updateOne(
            {
                _id: req.body.bussinessId,
            },
            { packageId: packageId }
        );
        return res.status(200).json({
            success: true,
            message: 'Bussiness package Updated successfully.',
        });
    } catch (err) {
        res.status(500).send({
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

exports.getBussinessById = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(401)
            .json({ success: false, message: 'Please login again.' });
    }
    try {
        const bussinesss = await bussiness.findOne({
            _id: req.params.businessId,
        });
        if (bussinesss == null) {
            res.status(404).send({
                success: false,
                message: "No Business found'!.",
            });
        }
        return res.status(200).json({
            success: true,
            data: {
                bussiness: bussinesss,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

exports.getBusinessStat = async (req, res) => {
    try {
        var approved,
            request,
            block,
            updateLoc,
            spam = 0;

        await bussiness.countDocuments(
            {
                status: '0',
            },
            function (err, result) {
                block = result;
            }
        );
        await bussiness.countDocuments(
            {
                status: '1',
            },
            function (err, result) {
                request = result;
            }
        );
        await bussiness.countDocuments(
            {
                status: '2',
            },
            function (err, result) {
                approved = result;
            }
        );
        var response = {
            total: approved + request + block,
            approved: approved,
            request: request,
            block: block,
            updateLoc: 0,
            spam: spam,
        };
        return res.status(200).json({
            success: true,
            data: {
                businessAnalysis: response,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};
exports.getAllBussiness = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(401)
            .json({ success: false, message: 'Please login again.' });
    }
    try {
        var pageNo = parseInt(req.query.pageNo);
        var size = parseInt(req.query.size);
        var query = {};
        if (pageNo < 0 || pageNo === 0) {
            return res.status(400).json({
                success: false,
                message: 'invalid page number, should start with 1',
            });
        }
        query.skip = size * (pageNo - 1);
        query.limit = size;

        bussiness.find({}, {}, query, async function (err, data) {
            // Mongo command to fetch all data from collection.
            if (err) {
                res.status(400).json({
                    success: false,
                    message: 'Error fetching data',
                });
            } else {
                for (let index = 0; index < data.length; index++) {
                    await category
                        .find({ _id: data[index].categoryId })
                        .then((categories) => {
                            data[index].catName = '';
                            if (categories.length > 0) {
                                data[index].catName = categories[0].nameEn;
                            }
                        });

                    await rating
                        .find({ type: 1, businessId: data[index]._id })
                        .then((ratings) => {
                            data[index].review = ratings.length;
                            var totalScore = 0;
                            for (let i = 0; i < ratings.length; i++) {
                                totalScore += ratings[i].score;
                            }
                            var avgScore = totalScore / ratings.length;
                            data[index].rating = avgScore;
                        });
                }

                res.status(200).json({
                    success: true,
                    data: {
                        bussinesses: data,
                    },
                });
            }
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

// business export

exports.businessexcelGenrate = async (req, res) => {
    try {
        // Create a new instance of a Workbook class
        var workbook = new excel.Workbook();

        // Add Worksheets to the workbook
        var worksheet = workbook.addWorksheet('Business Data');

        // Create a reusable style
        var style = workbook.createStyle({
            font: {
                color: '#000000',
                size: 12,
            },
            numberFormat: '$#,##0.00; ($#,##0.00); -',
        });

        worksheet.cell(1, 1).string('Id').style(style);
        worksheet.cell(1, 2).string('BusinessName').style(style);
        worksheet.cell(1, 3).string('Status').style(style);
        worksheet.cell(1, 4).string('BusinessCategory').style(style);
        worksheet.cell(1, 5).string('Rating').style(style);
        worksheet.cell(1, 6).string('Review').style(style);
        worksheet.cell(1, 7).string('PhoneNumber').style(style);
        worksheet.cell(1, 8).string('EmailAddress').style(style);
        worksheet.cell(1, 9).string('Governorates').style(style);
        worksheet.cell(1, 10).string('RegisterDateTime').style(style);

        await bussiness.find().then((busines) => {
            for (var i = 0; i < busines.length; i++) {
                var rowNum = i + 2;
                worksheet.cell(rowNum, 1).string(busines[i].id).style(style);
                worksheet
                    .cell(rowNum, 2)
                    .string(busines[i].nameEn.toString())
                    .style(style);
                var status = null;
                if (busines[i].status == 1) {
                    status = 'Active';
                }
                worksheet.cell(rowNum, 3).string(status).style(style);
                worksheet
                    .cell(rowNum, 4)
                    .string(busines[i].catName)
                    .style(style);

                worksheet.cell(rowNum, 5).string('2.3 Rating').style(style);
                worksheet.cell(rowNum, 6).string('5 Star').style(style);
                worksheet
                    .cell(rowNum, 7)
                    .string(busines[i].primaryContact)
                    .style(style);
                worksheet
                    .cell(rowNum, 8)
                    .string(busines[i].primaryEmail)
                    .style(style);
                worksheet
                    .cell(rowNum, 9)
                    .string(busines[i].areaId)
                    .style(style);
                worksheet
                    .cell(rowNum, 10)
                    .string(busines[i].createdAt)
                    .style(style);
            }
        });
        workbook.write(`Business.xlsx`, res);
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};
