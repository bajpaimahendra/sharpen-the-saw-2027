const package = require('../models/packages.js');
const helper = require('../service/helper.js');
const business = require('../models/business.js');
const { async } = require('q');
var path = require('path');
const excel = require('excel4node');

// Create and Save a new User
exports.createPackage = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(401)
            .json({ success: false, message: 'Please login again.' });
    }

    let {
        nameEn,
        nameAr,
        subtitle,
        mostSell,
        businessinfo,
        businessName,
        address,
        contactnumber,
        emailAddress,
        businesshour,
        website,
        businessCategories,
        amenities,
        socialmedia,
        facebook,
        instagram,
        linkedin,
        twitter,
        countusersearch,
        countuserprofileview,
        seereview,
        seerating,
        seenumberofreview,
        managegalleryofbusiness,
        managegalleryuploadedusers,
        numberofbusinessimageupload,
        createoffer,
        numberofoffercreate,
        createevents,
        numberofeventcreate,
        seeoffersreceive,
        seeusersviewoffers,
        seeoffersvisit,
        seeeventsreceive,
        seeusersviewevents,
        seeeventssvisit,
        seecountusersvisitplace,
        seecountuserssharebusiness,
    } = req.body;
    try {
        const newPackage = await package.create({
            nameEn,
            nameAr,
            subtitle,
            status: 1,
            mostSell,
            businessinfo,
            businessName,
            address,
            contactnumber,
            emailAddress,
            businesshour,
            website,
            businessCategories,
            amenities,
            socialmedia,
            facebook,
            instagram,
            linkedin,
            twitter,
            countusersearch,
            countuserprofileview,
            seereview,
            seerating,
            seenumberofreview,
            managegalleryofbusiness,
            managegalleryuploadedusers,
            numberofbusinessimageupload,
            createoffer,
            numberofoffercreate,
            createevents,
            numberofeventcreate,
            seeoffersreceive,
            seeusersviewoffers,
            seeoffersvisit,
            seeeventsreceive,
            seeusersviewevents,
            seeeventssvisit,
            seecountusersvisitplace,
            seecountuserssharebusiness,
        });
        return res.status(201).json({
            success: true,
            data: {
                package: newPackage,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

// get all package
exports.getAllPackage = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(401)
            .json({ success: false, message: 'Please login again.' });
    }
    try {
        var pageNo = parseInt(req.query.pageNo);
        var size = parseInt(req.query.size);
        var query = {};
        if (pageNo < 0 || pageNo === 0) {
            return res.status(400).json({
                success: false,
                message: 'invalid page number, should start with 1',
            });
        }
        query.skip = size * (pageNo - 1);
        query.limit = size;

        await package.find(
            {},
            {
                nameEn: 1,
                nameAr: 1,
                status: 1,
            },
            query,
            async function (err, data) {
                // Mongo command to fetch all data from collection.
                if (err) {
                    res.status(400).json({ message: 'Error fetching data' });
                } else {
                    for (var i = 0; i < data.length; i++) {
                        helper.countNoofbusiness(data[i]._id).then((count) => {
                            data[i]['businessCount'] = count;
                            console.log('Bussiness:' + count);
                        });
                    }

                    res.status(200).json({
                        success: true,
                        data: {
                            packages: data,
                        },
                    });
                }
            }
        );
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

// Update a package
exports.updatePackage = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(401)
            .json({ success: false, message: 'Please login again.' });
    }

    let {
        nameEn,
        nameAr,
        subtitle,
        status,
        mostSell,
        businessName,
        address,
        contactnumber,
        emailAddress,
        businesshour,
        website,
        businessCategories,
        amenities,
        socialmedia,
        facebook,
        instagram,
        linkedin,
        twitter,
        countusersearch,
        countuserprofileview,
        seereview,
        seerating,
        seenumberofreview,
        managegalleryofbusiness,
        managegalleryuploadedusers,
        numberofbusinessimageupload,
        createoffer,
        numberofoffercreate,
        createevents,
        numberofeventcreate,
        seeoffersreceive,
        seeusersviewoffers,
        seeoffersvisit,
        seeeventsreceive,
        seeusersviewevents,
        seeeventssvisit,
        seecountusersvisitplace,
        seecountuserssharebusiness,
    } = req.body;

    try {
        const response = await package.updateOne(
            {
                _id: req.body.packageid,
            },
            {
                nameEn: nameEn,
                nameAr: nameAr,
                subtitle: subtitle,
                status: status,
                mostSell: mostSell,
                businessName: businessName,
                address: address,
                contactnumber: contactnumber,
                emailAddress: emailAddress,
                businesshour: businesshour,
                website: website,
                businessCategories: businessCategories,
                amenities: amenities,
                socialmedia: socialmedia,
                facebook: facebook,
                instagram: instagram,
                linkedin: linkedin,
                twitter: twitter,
                countusersearch: countusersearch,
                countuserprofileview: countuserprofileview,
                seereview: seereview,
                seerating: seerating,
                seenumberofreview: seenumberofreview,
                managegalleryofbusiness: managegalleryofbusiness,
                managegalleryuploadedusers: managegalleryuploadedusers,
                numberofbusinessimageupload: numberofbusinessimageupload,
                createoffer: createoffer,
                numberofoffercreate: numberofoffercreate,
                createevents: createevents,
                numberofeventcreate: numberofeventcreate,
                seeoffersreceive: seeoffersreceive,
                seeusersviewoffers: seeusersviewoffers,
                seeoffersvisit: seeoffersvisit,
                seeeventsreceive: seeeventsreceive,
                seeusersviewevents: seeusersviewevents,
                seeeventssvisit: seeeventssvisit,
                seecountusersvisitplace: seecountusersvisitplace,
                seecountuserssharebusiness: seecountuserssharebusiness,
            }
        );
        return res
            .status(200)
            .json({ success: true, message: 'Package Updated successfully.' });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

// Find a single package with packageid

exports.packfindid = async (req, res) => {
    try {
        if (req.params.packageId === null) {
            return res
                .status(400)
                .json({ success: false, message: 'Invalid PackageId' });
        }
        const isPackage = await package.findOne({ _id: req.params.packageId });
        if (isPackage != null) {
            await business.countDocuments(
                {
                    packageId: req.params.packageId,
                },
                async function (err, result) {
                    isPackage.businessCount = result;
                }
            );
        }
        return res.status(200).json({
            success: true,
            data: {
                package: isPackage,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};
// package import
exports.packageexcelgenerate = async (req, res) => {
    // return res.sendFile('/Users/marketing/Documents/slash_price.xlsx');

    // Save Note in the database
    try {
        // Create a new instance of a Workbook class
        var workbook = new excel.Workbook();

        // Add Worksheets to the workbook
        var worksheet = workbook.addWorksheet('Offersdata');
        var style = workbook.createStyle({
            font: {
                color: '#000000',
                size: 12,
            },
            numberFormat: '$#,##0.00; ($#,##0.00); -',
        });
        worksheet.cell(1, 1).string('Id').style(style);
        worksheet.cell(1, 2).string('PackageName').style(style);
        worksheet.cell(1, 3).string('Subtitle').style(style);
        worksheet.cell(1, 4).string('Status').style(style);
        worksheet.cell(1, 5).string('MostSelled').style(style);
        worksheet.cell(1, 6).string('BusinessInformation').style(style);
        worksheet.cell(1, 7).string('BusinessName').style(style);
        worksheet.cell(1, 8).string('Address').style(style);
        worksheet.cell(1, 9).string('contactnumber').style(style);
        worksheet.cell(1, 10).string('EmailAddress').style(style);

        await package.find().then((packagelist) => {
            for (var i = 0; i < packagelist.length; i++) {
                var rowNum = i + 2;

                worksheet
                    .cell(rowNum, 1)
                    .string(packagelist[i].id)
                    .style(style);
                worksheet
                    .cell(rowNum, 2)
                    .string(packagelist[i].nameEn.toString())
                    .style(style);
                worksheet
                    .cell(rowNum, 3)
                    .string(packagelist[i].subtitle.toString())
                    .style(style);
                var status = null;
                if (packagelist[i].status == 1) {
                    status = 'Active';
                }
                worksheet.cell(rowNum, 4).string(status).style(style);
                worksheet
                    .cell(rowNum, 5)
                    .string(packagelist[i].mostSell.toString())
                    .style(style);
                worksheet
                    .cell(rowNum, 6)
                    .string(packagelist[i].businessinfo)
                    .style(style);
                worksheet
                    .cell(rowNum, 7)
                    .string(packagelist[i].businessName)
                    .style(style);
                worksheet
                    .cell(rowNum, 8)
                    .string(packagelist[i].address)
                    .style(style);
                worksheet
                    .cell(rowNum, 9)
                    .string(packagelist[i].contactnumber)
                    .style(style);
                worksheet
                    .cell(rowNum, 10)
                    .string(packagelist[i].emailAddress)
                    .style(style);
            }
        });
        workbook.write(`Package.xlsx`, res);
    } catch (error) {
        console.error(error.stack);
    }
};
