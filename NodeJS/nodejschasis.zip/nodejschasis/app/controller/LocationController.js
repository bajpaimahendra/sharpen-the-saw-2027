const location = require('../models/location.js');
const helper = require('../service/helper.js');

// Create and Save a new User
exports.createLocation = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (! result) {
        return res.status(401).json({success: false, message: 'Please login again.'});
    }

    let {
        nameEn,
        nameAr,
        catId,
        country,
        image,
        latitude,
        longitude,
        website,
        hours
    } = req.body;

    try {
        const newlocation = await location.create({
            nameEn,
            nameAr,
            catId,
            country,
            image,
            latitude,
            longitude,
            website,
            hours,
            status: 1
        });

        return res.status(201).json({
            success: true,
            data: {
                location: newlocation
            }
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Some error occurred while creating the Ticket.'
        });
        console.error(err.stack || err);
    }
};

// Create and Save a new User
exports.updateLocation = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (! result) {
        return res.status(401).json({success: false, message: 'Please login again.'});
    }

    let {
        nameEn,
        nameAr,
        catId,
        country,
        image,
        latitude,
        longitude,
        website,
        hours
    } = req.body;

    try {
        const newlocation = await location.updateOne({
            _id: req.body.locId
        }, {
            nameEn: nameEn,
            nameAr: nameAr,
            catId: catId,
            country: country,
            image: image,
            latitude: latitude,
            longitude: longitude,
            website: website,
            hours: hours,
            status: 1
        });

        return res.status(200).json({success: true, message: 'Location Updated successfully.'});
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Some error occurred while creating the Ticket.'
        });
        console.error(err.stack || err);
    }
};

// Create and Save a new User
exports.getLocation = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (! result) {
        return res.status(400).json({success: false, message: 'Please login again.'});
    }
    try {
        var pageNo = parseInt(req.query.pageNo);
        var size = parseInt(req.query.size);
        var query = {};
        if (pageNo < 0 || pageNo === 0) {
            return res.status(400).json({success: false, message: 'invalid page number, should start with 1'});
        }
        query.skip = size * (pageNo - 1);
        query.limit = size;

        location.find({}, {}, query, function (err, data) { // Mongo command to fetch all data from collection.
            if (err) {
                res.status(400).json({success: true, message: 'Error fetching data'});
            } else {
                res.status(200).json({
                    success: true,
                    data: {
                        locations: data
                    }
                });
            }
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.'
        });
        console.error(err.stack || err);
    }
};
