const category = require('../models/category.js');
const favCategory = require('../models/favCategory.js');
const subcategory = require('../models/subCategory.js');
const helper = require('../service/helper.js');
const constant = require('../config/constant.js');
const Employee = require('../models/employee.js');

// Create and Save a new User
exports.createFavCategory = async (req, res) => {
    try {
        // find user
        const isUsrExist = await Employee.findOne({ _id: req.body.userId });
        if (isUsrExist == null) throw new Error('User Not Found!');

        // find category
        const isCategoryExist = await category.findOne({
            _id: req.body.categoryId,
        });
        if (isCategoryExist == null) throw new Error('Category Not Found!');

        const favavCategory = await favCategory.find({
            userId: req.body.userId,
            status: 1,
        });
        if (favavCategory.length == 5)
            throw new Error('Maximum 5 category allowd!');

        const isFavCategoryExist = await favCategory.find({
            categoryId: req.body.categoryId,
            userId: req.body.userId,
        });
        if (
            isFavCategoryExist.length > 0 &&
            isFavCategoryExist[0].status == 1
        ) {
            throw new Error('FavCategory already added!');
        }
        if (
            isFavCategoryExist.length > 0 &&
            isFavCategoryExist[0].status == 0
        ) {
            await favCategory.updateOne(
                { _id: isFavCategoryExist[0]._id },
                { status: 1 }
            );
            return res.status(200).json({
                success: true,
                message: 'Fav Category Updated successfully.',
            });
        }
        let { categoryId, userId } = req.body;
        const newFavCat = await favCategory.create({
            categoryId,
            userId,
            status: constant.ACTIVE,
        });
        return res.status(201).json({
            success: true,
            data: {
                favcategory: newFavCat,
            },
        });
    } catch (err) {
        res.status(400).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};
exports.updateFavCategory = async (req, res) => {
    try {
        const response = await favCategory.updateOne(
            {
                categoryId: req.body.categoryId,
                userId: req.body.userId,
            },
            {
                status: constant.INACTIVE,
            }
        );
        console.log(response);
        return res.status(200).json({
            success: true,
            message: 'Fav Category Removed successfully.',
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

// Create and Save a new User
exports.createCategory = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(401)
            .json({ success: false, message: 'Please login again.' });
    }

    let { nameEn, nameAr, description, image } = req.body;

    try {
        const newCat = await category.create({
            nameEn,
            nameAr,
            description,
            image,
            status: 1,
            isExplore: 0,
        });
        return res.status(201).json({
            success: true,
            data: {
                category: newCat,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

// Create and Save a new User
exports.createSubCategory = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(401)
            .json({ success: false, message: 'Please login again.' });
    }

    let { nameEn, nameAr, description, image, categoryId } = req.body;

    try {
        const newSubCat = await subcategory.create({
            nameEn,
            nameAr,
            description,
            image,
            categoryId,
            status: 1,
        });
        return res.status(201).json({
            success: true,
            data: {
                subCategory: newSubCat,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

// Create and Save a new User
exports.updateCategory = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(401)
            .json({ success: false, message: 'Please login again.' });
    }

    let { nameEn, nameAr, description, image, status } = req.body;

    try {
        const response = await category.updateOne(
            {
                _id: req.body.categoryId,
            },
            {
                nameEn: nameEn,
                nameAr: nameAr,
                description: description,
                image: image,
                status: status,
            }
        );
        return res
            .status(200)
            .json({ success: true, message: 'Category Updated successfully.' });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};
// Create and Save a new User
exports.updateSubCategory = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(401)
            .json({ success: false, message: 'Please login again.' });
    }

    let { nameEn, nameAr, description, image, status, categoryId } = req.body;

    try {
        const response = await subcategory.updateOne(
            {
                _id: req.body.subCategoryId,
            },
            {
                nameEn: nameEn,
                nameAr: nameAr,
                description: description,
                image: image,
                categoryId: categoryId,
                status: status,
            }
        );
        return res.status(200).json({
            success: true,
            message: 'Sub Category Updated successfully.',
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

// Create and Save a new User
exports.getAllCategory = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(401)
            .json({ success: false, message: 'Please login again.' });
    }
    try {
        var pageNo = parseInt(req.query.pageNo);
        var size = parseInt(req.query.size);
        var query = {};
        if (pageNo < 0 || pageNo === 0) {
            return res.status(400).json({
                success: false,
                message: 'invalid page number, should start with 1',
            });
        }
        query.skip = size * (pageNo - 1);
        query.limit = size;

        category.find({}, {}, query, function (err, data) {
            // Mongo command to fetch all data from collection.
            if (err) {
                res.status(400).json({ message: 'Error fetching data' });
            } else {
                res.status(200).json({
                    success: true,
                    data: {
                        categories: data,
                    },
                });
            }
        });

        // .catch(error => next(customErrors.getCustomError(error)));
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

// Create and Save a new User
exports.getAllCategoryByUser = async (req, res) => {
    try {
        const categorys = await helper.allCatByUser(req.params.userId);
        res.status(200).json({
            success: true,
            data: {
                categories: categorys,
            },
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};

// Create and Save a new User
exports.getAllSubCategory = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(401)
            .json({ success: false, message: 'Please login again.' });
    }
    try {
        var pageNo = parseInt(req.query.pageNo);
        var size = parseInt(req.query.size);
        var query = {};
        if (pageNo < 0 || pageNo === 0) {
            return res.status(400).json({
                success: false,
                message: 'invalid page number, should start with 1',
            });
        }
        query.skip = size * (pageNo - 1);
        query.limit = size;

        subcategory.find({}, {}, query, function (err, data) {
            // Mongo command to fetch all data from collection.
            if (err) {
                res.status(400).json({ message: 'Error fetching data' });
            } else {
                res.status(200).json({
                    success: true,
                    data: {
                        subCategories: data,
                    },
                });
            }
        });

        // .catch(error => next(customErrors.getCustomError(error)));
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};
// Create and Save a new User
exports.getCategoryById = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(401)
            .json({ success: false, message: 'Please login again.' });
    }
    try {
        const query = {
            _id: req.params.categoryId,
        };

        category.find(query).then((categories) => {
            if (categories.length > 0) {
                return res.status(200).json({
                    success: true,
                    data: {
                        categories: categories,
                    },
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: "No category found'!.",
                });
            }
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};
// Create and Save a new User
exports.getSubCategoryByCatId = async (req, res) => {
    const authtoken = req.headers['token'];
    let result = await helper.validateToken(authtoken);

    if (!result) {
        return res
            .status(401)
            .json({ success: false, message: 'Please login again.' });
    }
    try {
        const query = {
            categoryId: req.params.categoryId,
        };

        subcategory.find(query).then((subcategories) => {
            if (subcategories.length > 0) {
                return res.status(200).json({
                    success: true,
                    data: {
                        subCategories: subcategories,
                    },
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: "No category found'!.",
                });
            }
        });
    } catch (err) {
        res.status(500).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};
