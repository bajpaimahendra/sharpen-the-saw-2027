const trxnHistory = require('../models/trxnHistory.js');
const users = require('../models/employee.js');

exports.createTxnHistory = async (req, res) => {
    try {
        let { userId, from, to, distance } = req.body;

        const response = await trxnHistory.create({
            userId,
            from,
            to,
            distance,
        });
        res.status(200).send({
            success: true,
            trxn: response,
        });
    } catch (err) {
        res.status(400).send({
            success: false,
            message:
                err.message ||
                'Some error occurred while creating the User DeviceInfo.',
        });
        console.error(err.stack || err);
    }
};
exports.getTrxnhistoryByUser = async (req, res) => {
    try {
        var pageNo = parseInt(req.query.pageNo);
        var size = parseInt(req.query.size);
        var queryDate = parseInt(req.query.date);
        if (
            pageNo < 0 ||
            pageNo === 0 ||
            size < 0 ||
            size === 0 ||
            queryDate == null
        )
            if (isUsrExist == null)
                throw new Error('Invalid page number, size or date');
        const isUsrExist = await users.findOne({ _id: req.params.userId });
        if (isUsrExist == null) throw new Error('User Not Found!');
        var now = new Date();

        let start = new Date(
            now.getFullYear(),
            now.getMonth(),
            now.getDate(),
            0,
            0,
            0
        );

        let end = new Date(
            now.getFullYear(),
            now.getMonth(),
            now.getDate(),
            23,
            59,
            59
        );

        var query = {};
        query.skip = size * (pageNo - 1);
        query.limit = size;
        var historyArray = [];
        var noOfPlaceVisted,
            totalDist = 0;

        await trxnHistory.find(
            { createdAt: { $gte: start, $lt: end }, userId: req.params.userId },
            {},
            query,
            function (err, data) {
                noOfPlaceVisted = data.length;
                for (let i = 0; i < data.length; i++) {
                    totalDist += data[i].distance;
                    var response1 = {
                        from: 'Brijwai Centrum',
                        to: 'VishalMegart',
                        fromfavName: 'Home',
                        tofavName: 'Grocery Store',
                        startTime: data[i].createdAt,
                        distance: data[i].distance + 'km',
                    };
                    historyArray.push(response1);
                }
            }
        );

        var response = {
            totalDist: totalDist + ' km',
            noOfPlaceVisted: noOfPlaceVisted,
            totalTime: '1 hr 3min',
        };

        return res.status(200).json({
            success: true,
            data: {
                user: isUsrExist,
                trxnData: response,
                trxnHistory: historyArray,
            },
        });
    } catch (err) {
        res.status(400).send({
            success: false,
            message: err.message || 'Something went wrong!.',
        });
        console.error(err.stack || err);
    }
};
