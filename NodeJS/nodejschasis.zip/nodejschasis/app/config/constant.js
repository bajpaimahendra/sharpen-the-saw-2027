module.exports = {
    url: 'mongodb://localhost:27017/test',
    // mongodb://myUserName:MyPassword@ElasticIP:27017/databaseName?authSource=admin

    OTP_EXPIRE: 7200000,
    HOST: '139.59.74.139',
    USER: 'vinay',
    PASSWORD: 'ProjectLifeline101',
    DB: 'gene_local',
    dialect: 'mysql',

    pool: {
        max: 5,
        min: 0,
        acquire: 30000,
    },
    FILE_PATH: '/Users/marketing/Documents/node_images/',
    // FILE_PATH: '/home/vinay/node_images/',
    APPLICATION_PATH: 'http://199.241.139.22:9090/download/image/',
    AUTH: 'R2VuZTpnZW5lQDEyMw==',
    SMTP_HOST: 'smtp.office365.com',
    SMTP_PORT: 587,
    SMTP_USER: 'dheeraj.singhal@wanbuffer.com',
    SMTP_PWD: 'HEROcat10#@',
    INACTIVE: 0,
    ACTIVE: 1,
    SUSPEND: 2,
    BLOCK: 3,
    OPEN_TICKET: 1,
    PROCESS_TICKET: 2,
    CLOSE_TICKET: 3,
    DISTANCE_RANGE: 10,
};
