const nodemailer = require('nodemailer');
const config = require('../config/constant.js');
//const apiresponse = require("./ApiResponse.js");
const Employee = require('../models/employee.js');
const business = require('../models/business.js');
const category = require('../models/category.js');
const favCategory = require('../models/favCategory.js');

var http = require('http');
// Require library
var excel = require('excel4node');
const { async } = require('q');
http.createServer(function (req, res) {});

var html =
    '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n' +
    '<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">\r\n' +
    '<head>\r\n' +
    '<!--[if gte mso 9]>\r\n' +
    '	<xml>\r\n' +
    '		<o:OfficeDocumentSettings>\r\n' +
    '		<o:AllowPNG/>\r\n' +
    '		<o:PixelsPerInch>96</o:PixelsPerInch>\r\n' +
    '		</o:OfficeDocumentSettings>\r\n' +
    '	</xml>\r\n' +
    '	<![endif]-->\r\n' +
    '<meta http-equiv="Content-type" content="text/html; charset=utf-8" />\r\n' +
    '<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />\r\n' +
    '<meta http-equiv="X-UA-Compatible" content="IE=edge" />\r\n' +
    '<meta name="format-detection" content="date=no" />\r\n' +
    '<meta name="format-detection" content="address=no" />\r\n' +
    '<meta name="format-detection" content="telephone=no" />\r\n' +
    '<meta name="x-apple-disable-message-reformatting" />\r\n' +
    '<!--[if !mso]><!-->\r\n' +
    '<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i&display=swap" rel="stylesheet" />\r\n' +
    '<!--<![endif]-->\r\n' +
    '<title>Email Template</title>\r\n' +
    '<!--[if gte mso 9]>\r\n' +
    '	<style type="text/css" media="all">\r\n' +
    '		sup { font-size: 100% !important; }\r\n' +
    '	</style>\r\n' +
    '	<![endif]-->\r\n' +
    '\r\n' +
    '<style type="text/css" media="screen">\r\n' +
    '		body { padding:0 !important; margin:0 auto !important; display:block !important; min-width:100% !important; width:100% !important; background:#f4ecfa; -webkit-text-size-adjust:none }\r\n' +
    '		a { color:#f3189e; text-decoration:none }\r\n' +
    '		p { padding:0 !important; margin:0 !important } \r\n' +
    '		img { margin: 0 !important; -ms-interpolation-mode: bicubic; /* Allow smoother rendering of resized image in Internet Explorer */ }\r\n' +
    '\r\n' +
    '		a[x-apple-data-detectors] { color: inherit !important; text-decoration: inherit !important; font-size: inherit !important; font-family: inherit !important; font-weight: inherit !important; line-height: inherit !important; }\r\n' +
    '		\r\n' +
    '		.btn-16 a { display: block; padding: 15px 35px; text-decoration: none; }\r\n' +
    '		.btn-20 a { display: block; padding: 15px 35px; text-decoration: none; }\r\n' +
    '\r\n' +
    '		.l-white a { color: #ffffff; }\r\n' +
    '		.l-black a { color: #282828; }\r\n' +
    '		.l-pink a { color: #f3189e; }\r\n' +
    '		.l-grey a { color: #6e6e6e; }\r\n' +
    '		.l-purple a { color: #9128df; }\r\n' +
    '\r\n' +
    '        .vertical-line{\r\n' +
    '        display: inline-block;\r\n' +
    '        border-left: 1px solid #ccc;\r\n' +
    '        margin: 0 10px;\r\n' +
    '        height: 125px;\r\n' +
    '    }\r\n' +
    '\r\n' +
    '		.gradient { background: linear-gradient(to right, #9028df 0%,#f3189e 100%); }\r\n' +
    '\r\n' +
    '		.btn-secondary { border-radius: 10px; background: linear-gradient(to right, #9028df 0%,#f3189e 100%); }\r\n' +
    '\r\n' +
    '				\r\n' +
    '		/* Mobile styles */\r\n' +
    '		@media only screen and (max-device-width: 480px), only screen and (max-width: 480px) {\r\n' +
    '			.mpx-10 { padding-left: 10px !important; padding-right: 10px !important; }\r\n' +
    '\r\n' +
    '			.mpx-15 { padding-left: 15px !important; padding-right: 15px !important; }\r\n' +
    '\r\n' +
    '			u + .body .gwfw { width:100% !important; width:100vw !important; }\r\n' +
    '\r\n' +
    '			.td,\r\n' +
    '			.m-shell { width: 100% !important; min-width: 100% !important; }\r\n' +
    '			\r\n' +
    '			.mt-left { text-align: left !important; }\r\n' +
    '			.mt-center { text-align: center !important; }\r\n' +
    '			.mt-right { text-align: right !important; }\r\n' +
    '			\r\n' +
    '			.me-left { margin-right: auto !important; }\r\n' +
    '			.me-center { margin: 0 auto !important; }\r\n' +
    '			.me-right { margin-left: auto !important; }\r\n' +
    '\r\n' +
    '			.mh-auto { height: auto !important; }\r\n' +
    '			.mw-auto { width: auto !important; }\r\n' +
    '\r\n' +
    '			.fluid-img img { width: 50% !important; max-width: 50% !important; height: auto !important; }\r\n' +
    '\r\n' +
    '			.column,\r\n' +
    '			.column-top,\r\n' +
    '			.column-dir-top { float: left !important; width: 100% !important; display: block !important; }\r\n' +
    '\r\n' +
    '			.m-hide { display: none !important; width: 0 !important; height: 0 !important; font-size: 0 !important; line-height: 0 !important; min-height: 0 !important; }\r\n' +
    '			.m-block { display: block !important; }\r\n' +
    '\r\n' +
    '			.mw-15 { width: 15px !important; }\r\n' +
    '\r\n' +
    '			.mw-2p { width: 2% !important; }\r\n' +
    '			.mw-32p { width: 32% !important; }\r\n' +
    '			.mw-49p { width: 49% !important; }\r\n' +
    '			.mw-50p { width: 50% !important; }\r\n' +
    '			.mw-100p { width: 100% !important; }\r\n' +
    '\r\n' +
    '			.mmt-0 { margin-top: 0 !important; }\r\n' +
    '		}\r\n' +
    '\r\n' +
    '			</style>\r\n' +
    '</head>\r\n' +
    '<body class="body" style="padding:0 !important; margin:0 auto !important; display:block !important; min-width:100% !important; width:100% !important; background:#f4ecfa; -webkit-text-size-adjust:none;">\r\n' +
    '<center>\r\n' +
    '<table width="100%" border="0" cellspacing="0" cellpadding="0" style="margin: 0; padding: 0; width: 100%; height: 100%;" bgcolor="#f4ecfa" class="gwfw">\r\n' +
    '<tr>\r\n' +
    '<td style="margin: 0; padding: 0; width: 100%; height: 100%;" align="center" valign="top">\r\n' +
    '<table width="600" border="0" cellspacing="0" cellpadding="0" class="m-shell">\r\n' +
    '<tr>\r\n' +
    '<td class="td" style="width:600px; min-width:600px; font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal;">\r\n' +
    '<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '<tr>\r\n' +
    '<td class="mpx-10">\r\n' +
    '\r\n' +
    '<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '<tr>\r\n' +
    '<td class="text-12 c-grey l-grey a-right py-20" style="font-size:12px; line-height:16px; font-family:\'PT Sans\', Arial, sans-serif; min-width:auto !important; color:#6e6e6e; text-align:right; padding-top: 20px; padding-bottom: 20px;">\r\n' +
    '<a href="#" target="_blank" class="link c-grey" style="text-decoration:none; color:#6e6e6e;"><span class="link c-grey" style="text-decoration:none; color:#6e6e6e;">WanBuffer Services</span></a>\r\n' +
    '</td>\r\n' +
    '</tr>\r\n' +
    '</table> \r\n' +
    '\r\n' +
    '<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '<tr>\r\n' +
    '<td class="gradient pt-10" style="border-radius: 10px 10px 0 0; padding-top: 10px;" bgcolor="#f3189e">\r\n' +
    '<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '<tr>\r\n' +
    '<td style="border-radius: 10px 10px 0 0;" bgcolor="#ffffff">\r\n' +
    '\r\n' +
    '<!-- <table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '<tr>\r\n' +
    '<td class="img-center p-30 px-15" style="font-size:0pt; line-height:0pt; text-align:center; padding: 30px; padding-left: 15px; padding-right: 15px;">\r\n' +
    '<a href="#" target="_blank"><img src="https://www.psd2newsletters.com/templates/purple/images/logo.png" width="112" height="43" border="0" alt="" /></a>\r\n' +
    '</td>\r\n' +
    '</tr>\r\n' +
    '</table> -->\r\n' +
    '\r\n' +
    '\r\n' +
    '<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '<tr>\r\n' +
    '<td class="px-50 mpx-15" style="padding-left: 50px; padding-right: 50px;">\r\n' +
    '\r\n' +
    '<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '<tr>\r\n' +
    '<td class="pb-50" style="padding-bottom: 50px;">\r\n' +
    '<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '<tr>\r\n' +
    '<td class="fluid-img img-center pb-50" style="font-size:0pt; line-height:0pt; text-align:center; padding-bottom: 50px; padding-top: 50px;">\r\n' +
    '<img src="http://content.beyouplus.com/appImage/byplogo.png" width="175" height="100" border="0" alt="" />\r\n' +
    '</td>\r\n' +
    '</tr>\r\n' +
    '<tr>\r\n' +
    '	<td class="fluid-img img-center pb-50" style="font-size:0pt; line-height:0pt; text-align:center; padding-bottom: 50px;">\r\n' +
    '	<img src="https://www.psd2newsletters.com/templates/purple/images/img_intro_1.png" width="280" height="280" border="0" alt="">\r\n' +
    '	</td>\r\n' +
    '	</tr>\r\n' +
    '<tr>\r\n' +
    '<td class="title-36 a-center pb-15" style="font-size:36px; line-height:40px; color:#282828; font-family:\'PT Sans\', Arial, sans-serif; min-width:auto !important; text-align:center; padding-bottom: 15px;">\r\n' +
    "<strong>We're happy you're here!</strong>\r\n" +
    '</td>\r\n' +
    '</tr>\r\n' +
    '<tr>\r\n' +
    '<td class="text-16 lh-26 a-center pb-25" style="font-size:16px; color:#6e6e6e; font-family:\'PT Sans\', Arial, sans-serif; min-width:auto !important; line-height: 26px; text-align:center; padding-bottom: 25px;">\r\n' +
    '    Hi Bharat, Welcome to WanBuffer!<br>\r\n' +
    "    You've taken your first step towards happier,healthier skin & hair.<br>\r\n" +
    '    Your counsellor buddy will be in touch with you shortly.<br>\r\n' +
    '    Looking forward to serving your aesthetic needs!\r\n' +
    '</td>\r\n' +
    '</tr>\r\n' +
    '<tr>\r\n' +
    '<td align="center">\r\n' +
    '\r\n' +
    '<table border="0" cellspacing="0" cellpadding="0" style="min-width: 200px;">\r\n' +
    '<tr>\r\n' +
    '<td class="btn-16 c-white l-white" bgcolor="#f3189e" style="font-size:16px; line-height:20px; mso-padding-alt:15px 35px; font-family:\'PT Sans\', Arial, sans-serif; text-align:center; font-weight:bold; text-transform:uppercase; border-radius:25px; min-width:auto !important; color:#ffffff;">\r\n' +
    '<a href="http://promo.beyouplus.com/" target="_blank" class="link c-white" style="display: block; padding: 15px 35px; text-decoration:none; color:#ffffff;">\r\n' +
    '<span class="link c-white" style="text-decoration:none; color:#ffffff;">Let’s begin</span>\r\n' +
    '</a>\r\n' +
    '</td>\r\n' +
    '</tr>\r\n' +
    '</table>\r\n' +
    '\r\n' +
    '</td>\r\n' +
    '</tr>\r\n' +
    '</table>\r\n' +
    '</td>\r\n' +
    '</tr>\r\n' +
    '</table>\r\n' +
    '\r\n' +
    '\r\n' +
    '<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '<tr>\r\n' +
    '<td class="pb-50" style="padding-bottom: 50px;">\r\n' +
    '<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '<tr>\r\n' +
    '<td class="img" height="1" bgcolor="#ebebeb" style="font-size:0pt; line-height:0pt; text-align:left;">&nbsp;</td>\r\n' +
    '</tr>\r\n' +
    '</table>\r\n' +
    '</td>\r\n' +
    '</tr>\r\n' +
    '</table>\r\n' +
    '\r\n' +
    '\r\n' +
    '<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '<tr>\r\n' +
    '<td class="pb-15" style="padding-bottom: 15px;">\r\n' +
    '<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '<tr>\r\n' +
    '<td class="title-26 a-center pb-35" style="font-size:26px; line-height:30px; color:#282828; font-family:\'PT Sans\', Arial, sans-serif; min-width:auto !important; text-align:center; padding-bottom: 35px;">\r\n' +
    '<strong>What else?</strong>\r\n' +
    '</td>\r\n' +
    '</tr>\r\n' +
    '<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '    <tbody><tr>\r\n' +
    '    <td class="py-50" style="padding-top: 20px; padding-bottom: 20px;">\r\n' +
    '    <table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '    <tbody><tr>\r\n' +
    '    <th class="column-top" valign="top" width="240" style="font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; vertical-align:top;">\r\n' +
    '    <table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '    <tbody><tr>\r\n' +
    '    <td class="p-30 mpx-15" style="border-radius: 10px; padding: 30px;" bgcolor="#f4ecfa">\r\n' +
    '    <table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '    <tbody><tr>\r\n' +
    '    <td>\r\n' +
    '        \r\n' +
    '    <table width="100%" border="0" cellspacing="0" cellpadding="0" style="position: relative; z-index: 1; margin-top: -90px;">\r\n' +
    '    <tbody><tr>\r\n' +
    '    <td class="img-center pb-20" style="font-size:0pt; line-height:0pt; text-align:center; padding-bottom: 20px;">\r\n' +
    '    \r\n' +
    '    </td>\r\n' +
    '    </tr>\r\n' +
    '    </tbody></table>\r\n' +
    '    </td>\r\n' +
    '    </tr>\r\n' +
    '    <tr>\r\n' +
    '        \r\n' +
    '    <td class="title-20 a-center c-purple l-purple pb-5" style="font-size:20px; line-height:24px; font-family:PT Sans, Arial, sans-serif; min-width:auto !important; text-align:center; color:#9128df; padding-bottom: 5px;">\r\n' +
    '            <a href="http://promo.beyouplus.com/" target="_blank" class="link c-white">\r\n' +
    '                 <strong>Visit our website</strong>\r\n' +
    '                 </a>\r\n' +
    '    </td>\r\n' +
    '    </tr>\r\n' +
    '    <tr>\r\n' +
    '    <td class="text-16 lh-26 c-black l-black a-center" style="font-size:16px; font-family:PT Sans, Arial, sans-serif; min-width:auto !important; line-height: 26px; color:#282828; text-align:center;">\r\n' +
    '    <strong></strong>\r\n' +
    '    <br>\r\n' +
    '    <a href="http://promo.beyouplus.com/" target="_blank" class="link c-white">\r\n' +
    '    <img src="https://www.psd2newsletters.com/templates/purple/images/ico_searching.png" width="75" height="75" border="0" alt="" />\r\n' +
    '</a>    \r\n' +
    '</td>\r\n' +
    '    </tr>\r\n' +
    '    </tbody></table>\r\n' +
    '    </td>\r\n' +
    '    </tr>\r\n' +
    '    </tbody></table>\r\n' +
    '    </th>\r\n' +
    '</a>\r\n' +
    '    <th class="column-top mpb-100" valign="top" width="50" style="font-size:0pt; line-height:0pt; padding:0; margin:10px; font-weight:normal; vertical-align:top;"></th>\r\n' +
    '    <a href="http://promo.beyouplus.com/">\r\n' +
    '    <th class="column-top" valign="top" width="240" style="font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; vertical-align:top;">\r\n' +
    '    <table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '    <tbody><tr>\r\n' +
    '    <td class="p-30 mpx-15" style="border-radius: 10px; padding: 30px;" bgcolor="#f4ecfa">\r\n' +
    '    <table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '    <tbody><tr>\r\n' +
    '    <td>\r\n' +
    '    <table width="100%" border="0" cellspacing="0" cellpadding="0" style="position: relative; z-index: 1; margin-top: -90px;">\r\n' +
    '    <tbody><tr>\r\n' +
    '    <td class="img-center pb-20" style="font-size:0pt; line-height:0pt; text-align:center; padding-bottom: 20px;">\r\n' +
    '    \r\n' +
    '    </td>\r\n' +
    '    </tr>\r\n' +
    '    </tbody></table>\r\n' +
    '\r\n' +
    '    </td>\r\n' +
    '    </tr>\r\n' +
    '    <tr>\r\n' +
    '    <td class="title-20 a-center c-purple l-purple pb-5" style="font-size:20px; line-height:24px; font-family:PT Sans, Arial, sans-serif; min-width:auto !important; text-align:center; color:#9128df; padding-bottom: 5px;">\r\n' +
    '            <a href="http://blog.beyouplus.com" target="_blank" class="link c-white">\r\n' +
    '        <strong>Aesthetipedia</strong>\r\n' +
    '            </a>\r\n' +
    '    </td>\r\n' +
    '    </tr>\r\n' +
    '    <tr>\r\n' +
    '    <td class="text-16 lh-26 c-black l-black a-center" style="font-size:16px; font-family:PT Sans, Arial, sans-serif; min-width:auto !important; line-height: 26px; color:#282828; text-align:center;">\r\n' +
    '    <strong></strong>\r\n' +
    '    <br>\r\n' +
    '    <a href="http://blog.beyouplus.com" target="_blank" class="link c-white">\r\n' +
    '    <img src="https://www.psd2newsletters.com/templates/purple/images/ico_mail.png" width="75" height="75" border="0" alt="" />\r\n' +
    '    </a>\r\n' +
    '</td>\r\n' +
    '    </tr>\r\n' +
    '    </tbody></table>\r\n' +
    '    </td>\r\n' +
    '    </tr>\r\n' +
    '    </tbody></table>\r\n' +
    '    </th>\r\n' +
    '    </a>\r\n' +
    '    </tr>\r\n' +
    '    </tbody></table>\r\n' +
    '    </td>\r\n' +
    '    </tr>\r\n' +
    '    </tbody></table>\r\n' +
    '    \r\n' +
    '<tr>\r\n' +
    '<td class="pb-35" style="padding-bottom: 35px;">\r\n' +
    '<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '<tr>\r\n' +
    '\r\n' +
    '<td valign="top" class="img mw-15" width="80" style="font-size:0pt; line-height:0pt; text-align:left;"></td>\r\n' +
    '<tr>\r\n' +
    '        <td class="img" width="117" style="font-size:0pt; line-height:0pt; text-align:right;">\r\n' +
    '        <a href="https://apps.apple.com/in/app/beyouplus/id1498422803" target="_blank"><img src="https://www.psd2newsletters.com/templates/purple/images/btn_appstore.png" width="117" height="40" border="0" alt="" /></a>\r\n' +
    '        </td>\r\n' +
    '        <td class="img" width="15" style="font-size:0pt; line-height:0pt; text-align:left;"></td>\r\n' +
    '        <td class="img" width="117" style="font-size:0pt; line-height:0pt; text-align:left;">\r\n' +
    '        <a href="https://play.google.com/store/apps/details?id=com.app.beyouplus" target="_blank"><img src="https://www.psd2newsletters.com/templates/purple/images/btn_gplay.png" width="117" height="40" border="0" alt="" /></a>\r\n' +
    '        </td>\r\n' +
    '        </tr>\r\n' +
    '</tr>\r\n' +
    '</table>\r\n' +
    '</td>\r\n' +
    '</tr>\r\n' +
    '</td>\r\n' +
    '</tr>\r\n' +
    '</table>\r\n' +
    '</td>\r\n' +
    '</tr>\r\n' +
    '</table>\r\n' +
    '\r\n' +
    '</td>\r\n' +
    '</tr>\r\n' +
    '</table>\r\n' +
    '\r\n' +
    '</td>\r\n' +
    '</tr>\r\n' +
    '</table>\r\n' +
    '\r\n' +
    '</td>\r\n' +
    '</tr>\r\n' +
    '</table>\r\n' +
    '\r\n' +
    '\r\n' +
    '\r\n' +
    '\r\n' +
    '\r\n' +
    '\r\n' +
    '<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '<tr>\r\n' +
    '<td class="p-50 mpx-15" bgcolor="#949196" style="border-radius: 0 0 10px 10px; padding: 50px;">\r\n' +
    '<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n' +
    '        <tr>\r\n' +
    '    \r\n' +
    '                <td class="text-14 lh-24 a-center c-white l-white pb-20" style="font-size:14px; font-family:\'PT Sans\', Arial, sans-serif; min-width:auto !important; line-height: 24px; text-align:center; color:#ffffff; padding-bottom: 20px;">\r\n' +
    '                Sent with ❤ from WanBuffer\r\n' +
    '                \r\n' +
    '                </td>\r\n' +
    '                </tr>\r\n' +
    '<tr>\r\n' +
    '<td align="center" class="pb-20" style="padding-bottom: 20px;">\r\n' +
    '    \r\n' +
    '\r\n' +
    '<table border="0" cellspacing="0" cellpadding="0">\r\n' +
    '<tr>\r\n' +
    '<td class="img" width="34" style="font-size:0pt; line-height:0pt; text-align:left;">\r\n' +
    '<a href="https://www.facebook.com/BeYouPlus/" target="_blank"><img src="https://www.psd2newsletters.com/templates/purple/images/ico_facebook.png" width="34" height="34" border="0" alt="" /></a>\r\n' +
    '</td>\r\n' +
    '<td class="img" width="15" style="font-size:0pt; line-height:0pt; text-align:left;"></td>\r\n' +
    '<td class="img" width="34" style="font-size:0pt; line-height:0pt; text-align:left;">\r\n' +
    '<a href="https://www.instagram.com/beyouplus/?hl=en" target="_blank"><img src="https://www.psd2newsletters.com/templates/purple/images/ico_instagram.png" width="34" height="34" border="0" alt="" /></a>\r\n' +
    '</td>\r\n' +
    '<td class="img" width="15" style="font-size:0pt; line-height:0pt; text-align:left;"></td>\r\n' +
    '<td class="img" width="34" style="font-size:0pt; line-height:0pt; text-align:left;">\r\n' +
    '<a href="https://twitter.com/BeYouPlusApp" target="_blank"><img src="https://www.psd2newsletters.com/templates/purple/images/ico_twitter.png" width="34" height="34" border="0" alt="" /></a>\r\n' +
    '</td>\r\n' +
    '<td class="img" width="15" style="font-size:0pt; line-height:0pt; text-align:left;"></td>\r\n' +
    '<td class="img" width="34" style="font-size:0pt; line-height:0pt; text-align:left;">\r\n' +
    '<a href=" https://www.quora.com/profile/BeYouPlus-Expert" target="_blank"><img src="https://content.beyouplus.com/appImage/3.png" width="34" height="34" style="border-radius: 100%;" border="0" alt="" /></a>\r\n' +
    '</td>\r\n' +
    '<!-- <td class="img" width="15" style="font-size:0pt; line-height:0pt; text-align:left;"></td>\r\n' +
    '<td class="img" width="34" style="font-size:0pt; line-height:0pt; text-align:left;">\r\n' +
    '<a href="https://www.quora.com/profile/BeYouPlus-Expert" target="_blank"><img src="https://www.psd2newsletters.com/templates/purple/images/ico_quora.png" width="34" height="34" border="0" alt="" /></a>\r\n' +
    '</td> -->\r\n' +
    '</tr>\r\n' +
    '</table>\r\n' +
    '\r\n' +
    '</td>\r\n' +
    '</tr>\r\n' +
    '<tr>\r\n' +
    '    \r\n' +
    '<td class="text-14 lh-24 a-center c-white l-white pb-20" style="font-size:14px; font-family:\'PT Sans\', Arial, sans-serif; min-width:auto !important; line-height: 24px; text-align:center; color:#ffffff; padding-bottom: 20px;">\r\n' +
    'Sarthak Complex, 208, Swastik Society Cross Rd, Swastik Society, Navrangpura, Ahmedabad, Gujarat (380009)\r\n' +
    '<br />\r\n' +
    '<a href="tel:+919870293933" target="_blank" class="link c-white" style="text-decoration:none; color:#ffffff;"><span class="link c-white" style="text-decoration:none; color:#ffffff;">(987) 029-3933</span></a> \r\n' +
    '<br />\r\n' +
    '<a href="/cdn-cgi/l/email-protection#85ecebe3eac5f2e0e7f6ecf1e0abe6eae8" target="blank" class="link c-white" style="text-decoration:none; color:#ffffff;"><span class="link c-white" style="text-decoration:none; color:#ffffff;"><span class="cf_email_" data-cfemail="d2bbbcb4bd92a5b7b0a1bba6b7fcb1bdbf">support@wanbuffer.com</span></span></a><a href="www.website.com" target="_blank" class="link c-white" style="text-decoration:none; color:#ffffff;">&nbsp;&nbsp;<span class="link c-white" style="text-decoration:none; color:#ffffff;">www.wanbuffer.com</span></a>\r\n' +
    '</td>\r\n' +
    '</tr>\r\n' +
    '<tr>\r\n' +
    '<td align="center">\r\n' +
    '<!-- \r\n' +
    '<table border="0" cellspacing="0" cellpadding="0">\r\n' +
    '<tr>\r\n' +
    '<td class="img" width="117" style="font-size:0pt; line-height:0pt; text-align:left;">\r\n' +
    '<a href="#" target="_blank"><img src="https://www.psd2newsletters.com/templates/purple/images/btn_appstore.png" width="117" height="40" border="0" alt="" /></a>\r\n' +
    '</td>\r\n' +
    '<td class="img" width="15" style="font-size:0pt; line-height:0pt; text-align:left;"></td>\r\n' +
    '<td class="img" width="117" style="font-size:0pt; line-height:0pt; text-align:left;">\r\n' +
    '<a href="#" target="_blank"><img src="https://www.psd2newsletters.com/templates/purple/images/btn_gplay.png" width="117" height="40" border="0" alt="" /></a>\r\n' +
    '</td>\r\n' +
    '</tr>\r\n' +
    '</table> -->\r\n' +
    '\r\n' +
    '</td>\r\n' +
    '</tr>\r\n' +
    '</table>\r\n' +
    '</td>\r\n' +
    '</tr>\r\n' +
    '</table> \r\n' +
    '\r\n' +
    '\r\n' +
    '</center>\r\n' +
    '<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script></body>\r\n' +
    '</html>';

module.exports = {
    OkHandler: function (req, res) {
        const { apiResponse } = res.locals;
        if (apiResponse instanceof ApiResponse) {
            return res.status(apiResponse.statusCode).json(apiResponse.data);
        }
        return res.status(HttpStatus.NOT_FOUND).json('Something went wrong!');
    },

    // Function to generate OTP
    generateOTP: function (length) {
        // Declare a digits variable
        // which stores all digits
        var digits = '123456789';
        let OTP = '';
        for (let i = 0; i < length; i++) {
            OTP += digits[Math.floor(Math.random() * 10)];
        }
        return OTP;
    },

    errorHandler: function (err, req, res, next) {
        if (typeof err === 'string') {
            // custom application error
            return res.status(400).json({ message: err });
        }

        // default to 500 server error
        console.log(err.message);
        return res.status(500).json({ message: 'Something Went Wrong' });
    },

    basicAuth: function (req, res, next) {
        if (req.path.includes('/excel/')) {
            return next();
        }
        if (req.path === '/download/image/:name') {
            console.log('Ok');
            return next();
        }

        // check for basic auth header
        if (
            !req.headers.authorization ||
            req.headers.authorization.indexOf('Basic ') === -1
        ) {
            return res.status(401).json({
                success: false,
                message: 'Missing Authorization Header',
            });
        }

        // verify auth credentials
        const base64Credentials = req.headers.authorization.split(' ')[1];
        const credentials = Buffer.from(base64Credentials, 'base64').toString(
            'ascii'
        );
        const [username, password] = credentials.split(':');

        if (!(base64Credentials == config.AUTH)) {
            return res.status(403).json({
                success: false,
                message: 'Missing Authorization Header',
            });
        }

        // attach user to request object
        //req.user = user

        next();
    },

    restClient: function (mobile, otp) {
        var clientResponse = '';
        const data = JSON.stringify({
            mobile: mobile,
        });

        const options = {
            host: '139.59.74.139',
            port: 8081,
            path: '/api/otp/generate',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': data.length,
                Authorization: 'Basic ' + config.AUTH,
            },
        };

        const req = http.request(options, (res) => {
            // console.log(`statusCode: ${res.statusCode}`)

            res.on('data', (d) => {
                process.stdout.write(d);
                clientResponse = d;

                // console.log("\nClient Res:" + clientResponse);
            });
        });

        req.on('error', (error) => {
            console.error(error);
        });

        req.write(data);

        req.end();
    },
    sendMailer: function () {
        // var attachments = [{ filename: 'MTJ-BVH.pdf', path: '/Users/marketing/Documents/MTJ-BVH.pdf', contentType: 'application/pdf' }];

        //function mailer(from, to, subject, attachments, body) {

        // async..await is not allowed in global scope, must use a wrapper
        async function main() {
            // Generate test SMTP service account from smtp.email
            // Only needed if you don't have a real mail account for testing
            let testAccount = await nodemailer.createTestAccount();

            // create reusable transporter object using the default SMTP transport
            let transporter = nodemailer.createTransport({
                //host: "smtp.gmail.com",
                host: config.SMTP_HOST,
                port: config.SMTP_PORT,
                secure: false, // true for 465, false for other ports
                auth: {
                    // user: "mr.dheerajsinghal@gmail.com",
                    user: config.SMTP_USER,
                    pass: config.SMTP_PWD,
                },
            });

            // send mail with defined transport object
            let info = await transporter.sendMail({
                from: 'dheeraj.singhal@wanbuffer.com', // sender address
                to: 'dheeraj.singhal@wanbuffer.com,bharat.parmar@wanbuffer.com', // list of receivers
                subject: 'Welcome To Wanbuffer!', // Subject line
                text: 'Welcome To Wanbuffer!', // plain text body
                // attachments: attachments,
                //html: "<b>Hello world?</b>", // html body
                html: html,
            });

            console.log('Message sent: %s', info.messageId);

            // Preview only available when sending through an SMTP account
            console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));
        }

        main().catch(console.error);
    },

    validateToken: async function (token) {
        // var types = ['1', '2'];
        // type: { $nin: types, },
        const isUserLogin = await Employee.findOne({
            token: token,
        });

        if (isUserLogin != null) {
            var now = new Date();
            let timeDiff = now.getTime() - isUserLogin.updatedAt.getTime();
            if (timeDiff <= config.OTP_EXPIRE) {
                return true;
            }
        }
        return false;
    },
    distance: async function (lat1, lon1, lat2, lon2, unit) {
        if (lat1 == lat2 && lon1 == lon2) {
            return 0;
        } else {
            var radlat1 = (Math.PI * lat1) / 180;
            var radlat2 = (Math.PI * lat2) / 180;
            var theta = lon1 - lon2;
            var radtheta = (Math.PI * theta) / 180;
            var dist =
                Math.sin(radlat1) * Math.sin(radlat2) +
                Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
            if (dist > 1) {
                dist = 1;
            }
            dist = Math.acos(dist);
            dist = (dist * 180) / Math.PI;
            dist = dist * 60 * 1.1515;
            if (unit == 'K') {
                dist = dist * 1.609344;
            }
            if (unit == 'N') {
                dist = dist * 0.8684;
            }
            return dist;
        }
    },
    countNoofbusiness: async function (packageId) {
        const count = await business.countDocuments({ packageId: packageId });
        return count;
    },
    allCatByUser: async function (userId) {
        var response = await category.find({ isExplore: 1 });
        for (let i = 0; i < response.length; i++) {
            const isFavCategory = await favCategory.find({
                categoryId: response[i]._id,
                userId: userId,
            });
            response[i]['isFav'] = 0;
            if (isFavCategory.length > 0) {
                response[i]['isFav'] = isFavCategory[i].status;
            }
        }

        return response;
    },

    otpSender: function (email, otp) {
        // var attachments = [{ filename: 'MTJ-BVH.pdf', path: '/Users/marketing/Documents/MTJ-BVH.pdf', contentType: 'application/pdf' }];

        //function mailer(from, to, subject, attachments, body) {

        // async..await is not allowed in global scope, must use a wrapper
        async function main() {
            // Generate test SMTP service account from smtp.email
            // Only needed if you don't have a real mail account for testing
            let testAccount = await nodemailer.createTestAccount();

            // create reusable transporter object using the default SMTP transport
            let transporter = nodemailer.createTransport({
                //host: "smtp.gmail.com",
                host: config.SMTP_HOST,
                port: config.SMTP_PORT,
                secure: false, // true for 465, false for other ports
                auth: {
                    // user: "mr.dheerajsinghal@gmail.com",
                    user: config.SMTP_USER,
                    pass: config.SMTP_PWD,
                },
            });

            // send mail with defined transport object
            let info = await transporter.sendMail({
                from: 'dheeraj.singhal@wanbuffer.com', // sender address
                to: email,
                subject: 'OTP:FORGET PASSWORD', // Subject line
                text: 'Reset OTP is:' + otp + ' and validity is 2 hrs.', // plain text body
                // attachments: attachments,
                //html: "<b>Hello world?</b>", // html body
                //html: html
            });

            console.log('Message sent: %s', info.messageId);

            // Preview only available when sending through an SMTP account
            console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));
        }

        main().catch(console.error);
    },
    randomString: function (length) {
        var result = '';
        var characters =
            'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var charactersLength = characters.length;
        for (var i = 0; i < length; i++) {
            result += characters.charAt(
                Math.floor(Math.random() * charactersLength)
            );
        }
        return result;
    },
    checkSumOnPwd: function (pwd) {
        var crypto = require('crypto');
        var hmac = crypto.createHmac(
            'sha256',
            '4c1078fd-52e8-11ea-8109-028958215247'
        );
        data = hmac.update(pwd);
        gen_hmac = data.digest('hex');
        return gen_hmac;
    },
    excel: function () {
        // Create a new instance of a Workbook class
        var workbook = new excel.Workbook();

        // Add Worksheets to the workbook
        var worksheet = workbook.addWorksheet('Sheet 1');

        // Create a reusable style
        var style = workbook.createStyle({
            font: {
                color: '#000000',
                size: 12,
            },
            numberFormat: '$#,##0.00; ($#,##0.00); -',
        });

        worksheet.cell(1, 1).string('Id').style(style);
        worksheet.cell(1, 2).string('Name').style(style);
        worksheet.cell(1, 3).string('Email').style(style);

        for (var i = 2; i < 100; i++) {
            worksheet.cell(i, 1).string(i.toString()).style(style);
            worksheet.cell(i, 2).string('Dheeraj').style(style);
            worksheet.cell(i, 3).string('email@email.com').style(style);
        }

        workbook.write('/Users/marketing/Documents/Test' + i + '.xlsx');
        console.log('Excel generated succefully');
    },
};
