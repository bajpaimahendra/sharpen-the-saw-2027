const schedule = require('node-schedule');

const job = schedule.scheduleJob('0 0 0/1 * * *', function () {
    console.log('Test Cron Strated:' + new Date());
});
