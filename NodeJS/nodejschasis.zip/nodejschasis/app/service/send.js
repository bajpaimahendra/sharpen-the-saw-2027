var admin = require('firebase-admin');

var serviceAccount = require('/home/vinay/node/secret.json');

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    databaseURL: 'https://wanbuffer-8492e.firebaseio.com',
});

// This registration token comes from the client FCM SDKs.
var registrationToken = 'B5CBF21F5EC8341C';

var message = {
    data: {
        score: '850',
        time: '2:45',
    },
    token: registrationToken,
};
var payload = {
    notification: {
        title: 'This is a Notification',
        body: 'This is the body of the notification message.',
    },
};

var options = {
    priority: 'high',
    timeToLive: 60 * 60 * 24,
};

admin
    .messaging()
    .sendToDevice(registrationToken, payload, options)
    .then(function (response) {
        console.log('Successfully sent message:', response);
    })
    .catch(function (error) {
        console.log('Error sending message:', error);
    }); /*
// Send a message to the device corresponding to the provided
// registration token.
admin
    .messaging()
    .send(message)
    .then((response) => {
        // Response is a message ID string.
        console.log('Successfully sent message:', response);
    })
    .catch((error) => {
        console.log('Error sending message:', error);
    });
*/
