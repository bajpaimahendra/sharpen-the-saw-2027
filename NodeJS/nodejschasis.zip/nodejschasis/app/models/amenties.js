const mongoose = require('mongoose');
const { Schema } = mongoose;

const AmentiesSchema = mongoose.Schema(
    {
        nameEn: String,
        nameAr: String,
        image: String,
        status: {
            type: Number,
            required: true,
        },
    },
    { timestamps: true }
);

module.exports = mongoose.model('Amenties', AmentiesSchema);
