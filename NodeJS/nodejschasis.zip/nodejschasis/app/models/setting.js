const mongoose = require('mongoose');
const { Schema } = mongoose;

const SettingSchema = mongoose.Schema(
    {
        logoImage: String,
        nameEn: String,
        nameAr: String,
        tageLineEn: String,
        tageLineAr: String,
        addressEn: String,
        addressAr: String,
        emailEn: String,
        emailAr: String,
        contactEn: String,
        contactAr: String,
        latitude: String,
        longitude: String,
        gMapKey: String,
        mapBoxKey: String,
        firebaseKey: String,
        status: Number,
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model('Setting', SettingSchema);
