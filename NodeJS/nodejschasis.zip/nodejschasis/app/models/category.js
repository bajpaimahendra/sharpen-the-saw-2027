const mongoose = require('mongoose');
const { Schema } = mongoose;

const CategorySchema = mongoose.Schema(
    {
        nameEn: {
            type: String,
            required: true,
        },
        nameAr: {
            type: String,
            required: true,
        },
        description: String,
        status: {
            type: Number,
            required: true,
        },
        image: {
            type: String,
            required: true,
        },
        isExplore: Number,
        isFav: { type: Number, strict: false },
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model('Category', CategorySchema);
