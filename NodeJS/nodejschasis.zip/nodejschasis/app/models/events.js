const mongoose = require('mongoose');
const { Schema } = mongoose;

const EventsSchema = mongoose.Schema(
    {
        nameEn: String,
        nameAr: String,
        status: {
            type: Number,
            required: true,
        },
        descriptionEn: String,
        descriptionAr: String,
        bussinessId: String,
        startDate: Date,
        endDate: Date,
        image: String,
        deviceType: Number,
        publish: Date,
        latitude: String,
        longitude: String,
        userType: Number,
        bussinessName: { type: String, strict: false },
        area: String,
        isExplore: Number,
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model('Events', EventsSchema);
