const mongoose = require('mongoose');
const { Schema } = mongoose;

const CmsPagechema = mongoose.Schema(
    {
        nameEn: String,
        nameAr: String,
        metaData: String,
        metakeywords: String,
        metaDescription: String,
        status: {
            type: Number,
            required: true,
        },
        slug: String,
        desriptionEn: String,
        desriptionAr: String,
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model('cmsPage', CmsPagechema);
