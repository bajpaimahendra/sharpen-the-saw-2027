const mongoose = require('mongoose');
const { Schema } = mongoose;

const SubCategorySchema = mongoose.Schema(
    {
        nameEn: String,
        nameAr: String,
        description: String,
        status: Number,
        image: String,
        categoryId: String,
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model('SubCategory', SubCategorySchema);
