const mongoose = require('mongoose');
const { Schema } = mongoose;

const UserSchema = mongoose.Schema(
    {
        firstName: {
            type: String,
            required: true,
        },
        lastName: {
            type: String,
            required: true,
        },
        email: {
            type: String,
            required: true,
        },
        username: String,
        gender: {
            type: String,
            required: true,
        },
        status: {
            type: Number,
            required: true,
        },
        pwd: String,
        token: String,
        mobile: String,
        image: String,
        type: {
            type: Number,
            required: true,
        },
        governorates: String,
        createdBy: String,
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model('User', UserSchema);
