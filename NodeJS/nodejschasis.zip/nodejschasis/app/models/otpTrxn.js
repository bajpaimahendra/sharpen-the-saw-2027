const mongoose = require('mongoose');

const OtpTrxnSchema = mongoose.Schema(
    {
        email: String,
        otp: Number,
        mobile: String,
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model('OtpTrxn', OtpTrxnSchema);
