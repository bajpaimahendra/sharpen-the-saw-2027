const mongoose = require('mongoose');
const { Schema } = mongoose;

const ImagesSchema = mongoose.Schema(
    {
        businessId: {
            type: String,
            required: true,
        },
        imagePath: {
            type: String,
            required: true,
        },
        uploadBy: {
            type: String,
            required: true,
        },
        status: {
            type: Number,
            required: true,
        },
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model('Images', ImagesSchema);
