const mongoose = require('mongoose');
const { Schema } = mongoose;

const LabelSchema = mongoose.Schema(
    {
        labelRef: {
            type: String,
            required: true,
        },
        labelEn: {
            type: String,
            required: true,
        },
        labelAr: {
            type: String,
            required: true,
        },
        status: {
            type: String,
            required: true,
        },
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model('Label', LabelSchema);
