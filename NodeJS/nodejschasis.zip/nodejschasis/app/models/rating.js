const mongoose = require('mongoose');
const { Schema } = mongoose;

const RatingSchema = mongoose.Schema(
    {
        userName: String,
        businessId: String,
        userId: String,
        score: {
            type: Number,
            required: true,
        },
        description: String,
        type: {
            type: Number,
            required: true,
        },
        month: String,
        status: {
            type: Number,
            required: true,
        },
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model('Rating', RatingSchema);
