const mongoose = require('mongoose');
const { Schema } = mongoose;

const AreaSchema = mongoose.Schema(
    {
        nameEn: String,
        nameAr: String,
        country: String,
        status: {
            type: Number,
            required: true,
        },
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model('Area', AreaSchema);
