const mongoose = require('mongoose');
const { Schema } = mongoose;

const ScreensSchema = mongoose.Schema(
    {
        nameEn: String,
        nameAr: String,
        desriptionEn: String,
        desriptionAr: String,
        image: String,
        status: {
            type: Number,
            required: true,
        },
    },
    { timestamps: true }
);

module.exports = mongoose.model('Screens', ScreensSchema);
