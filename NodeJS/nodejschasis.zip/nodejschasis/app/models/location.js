const mongoose = require('mongoose');
const { Schema } = mongoose;

const LocationSchema = mongoose.Schema(
    {
        nameEn: String,
        nameAr: String,
        category: String,
        country: String,
        image: String,
        latitude: String,
        longitude: String,
        website: String,
        hours: Date,
        status: {
            type: Number,
            required: true,
        },
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model('Location', LocationSchema);
