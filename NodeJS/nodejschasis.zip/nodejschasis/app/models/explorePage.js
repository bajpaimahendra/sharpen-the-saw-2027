const mongoose = require('mongoose');
const { Schema } = mongoose;

const ExplorePageSchema = mongoose.Schema(
    {
        offers: String,
        events: String,
        packages: String,
        ads: String,
        topPics: String,
        categories: String,
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model('ExplorePage', ExplorePageSchema);
