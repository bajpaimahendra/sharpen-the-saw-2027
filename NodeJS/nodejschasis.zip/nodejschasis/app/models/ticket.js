const mongoose = require('mongoose');
const { Schema } = mongoose;

const TicketSchema = mongoose.Schema(
    {
        name: String,
        bussinessId: String,
        userId: String,
        description: String,
        type: String,
        assignedTo: String,
        status: {
            type: Number,
            required: true,
        },
        month: Number,
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model('Ticket', TicketSchema);
