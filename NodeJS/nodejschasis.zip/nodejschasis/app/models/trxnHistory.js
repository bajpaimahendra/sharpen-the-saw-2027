const mongoose = require('mongoose');
const { Schema } = mongoose;

const TrxnHistorySchema = mongoose.Schema(
    {
        userId: {
            type: String,
            required: true,
        },
        from: {
            type: String,
            required: true,
        },
        to: {
            type: String,
            required: true,
        },
        distance: {
            type: Number,
            required: true,
        },
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model('TrxnHistory', TrxnHistorySchema);
