const mongoose = require('mongoose');
const { Schema } = mongoose;

const UserAddressSchema = mongoose.Schema(
    {
        userId: {
            type: String,
            required: true,
        },
        locationId: {
            type: String,
            required: true,
        },
        landMark: {
            type: String,
            required: true,
        },
        type: {
            type: String,
            required: true,
        },
        status: Number,
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model('UserAddress', UserAddressSchema);
