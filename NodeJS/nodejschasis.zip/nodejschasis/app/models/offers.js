const mongoose = require('mongoose');
const { Schema } = mongoose;

const OffersSchema = mongoose.Schema(
    {
        nameEn: String,
        nameAr: String,
        descriptionEn: String,
        descriptionAr: String,
        status: {
            type: Number,
            required: true,
        },
        bussinessId: String,
        startDate: Date,
        endDate: Date,
        image: String,
        deviceType: Number,
        publish: Date,
        userType: Number,
        bussinessName: { type: String, strict: false },
        area: String,
        isExplore: Number,
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model('Offers', OffersSchema);
