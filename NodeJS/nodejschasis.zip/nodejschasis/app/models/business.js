const mongoose = require('mongoose');
const { Schema } = mongoose;

const Businesschema = mongoose.Schema(
    {
        nameEn: String,
        nameAr: String,
        addressLine1: String,
        addressLine2: String,
        categoryId: {
            type: String,
            required: true,
        },
        areaId: String,
        logo: String,
        primaryEmail: {
            type: String,
            required: true,
        },
        altEmail: String,
        primaryContact: {
            type: String,
            required: true,
        },
        altContact: String,
        packageId: String,
        workingHours: Schema.Types.Mixed,
        fbLink: String,
        InstLink: String,
        twitLink: String,
        linkedinLink: String,
        iosLink: String,
        andLink: String,
        website: String,
        latitude: String,
        longitude: String,
        createdBy: String,
        status: Number,
        catName: { type: String, strict: false },
        review: { type: Number, strict: false },
        rating: { type: Number, strict: false },
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model('Business', Businesschema);
