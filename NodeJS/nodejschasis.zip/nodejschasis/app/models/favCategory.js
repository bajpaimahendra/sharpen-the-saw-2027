const mongoose = require('mongoose');
const { Schema } = mongoose;

const FavCategorychema = mongoose.Schema(
    {
        categoryId: {
            type: String,
            required: true,
        },
        userId: {
            type: String,
            required: true,
        },
        status: {
            type: Number,
            required: true,
        },
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model('FavCategory', FavCategorychema);
