const mongoose = require('mongoose');
const { Schema } = mongoose;

const DeviceInfoSchema = mongoose.Schema(
    {
        userId: String,
        type: String,
        model: String,
        imei: String,
        deviceId: String,
        token: String,
        var1: String,
        mapView: {
            type: Number,
            required: true,
        },
        lang: {
            type: Number,
            required: true,
        },
        navigation: {
            type: Number,
            required: true,
        },
        navAlert: {
            type: Boolean,
            required: true,
        },
        locAlert: {
            type: Boolean,
            required: true,
        },
        offerEventAlert: {
            type: Boolean,
            required: true,
        },
    },
    {
        timestamps: true,
    }
);

module.exports = mongoose.model('DeviceInfo', DeviceInfoSchema);
