module.exports = (app) => {
    const controller = require('../controller/controller.js');
    const userController = require('../controller/UserController.js');
    const catController = require('../controller/CategortController.js');
    const cmsController = require('../controller/CmsController.js');
    const areaController = require('../controller/AreaController.js');
    const labelController = require('../controller/LabelController.js');
    const ticketController = require('../controller/TicketController.js');
    const amentiesController = require('../controller/AmentiesController.js');
    const offersController = require('../controller/OfferController.js');
    const eventsController = require('../controller/EventController.js');
    const explorePageController = require('../controller/ExplorePageController.js');
    const settingController = require('../controller/SettingController.js');
    const otpController = require('../controller/OtpController.js');
    const locationController = require('../controller/LocationController.js');
    const bussinessController = require('../controller/BusinessController.js');
    const packageController = require('../controller/PackageController.js');
    const ratingController = require('../controller/RatingController.js');
    const imageController = require('../controller/ImageController.js');
    const screenController = require('../controller/MobileScreenController.js');
    const trxnController = require('../controller/TrxnHistoryController.js');
    const excel = require('../service/excel.js');

    const multer = require('multer');

    const storage = multer.diskStorage({
        destination: (req, file, cb) => {
            cb(null, 'Users/marketing/Documents/');
        },
        filename: (req, file, cb) => {
            const fileName = file.originalname
                .toLowerCase()
                .split(' ')
                .join('-');
            cb(null, fileName);
        },
    });

    const upload = multer({
        storage: storage,
        fileFilter: (req, file, cb) => {
            cb(null, true);
            /* if (
                file.mimetype == 'image/png' ||
                file.mimetype == 'image/jpg' ||
                file.mimetype == 'image/jpeg' ||
                file.mimetype == 'image/gif'
            ) {
                cb(null, true);
            } else {
                cb(null, false);
                return cb(new Error('Allowed only .png, .jpg, .jpeg and .gif'));
            }*/
        },
    });

    // Create a new employee
    app.post('/user/signup', userController.signUp);

    // Get US=ser stats
    app.get('/user/analysis', userController.getUserStats);

    // Get LATEST USser INFO
    app.get('/user/recent', userController.getProfileForLatestUser);

    // Create a new user deviceInfo
    app.post('/user/device', userController.createDeviceInfo);

    // Get a  user deviceInfo
    app.get('/user/device', userController.getDeviceInfoByUser);

    // Create a new user Address
    app.post('/user/address', userController.addUserAddress);

    // Create a new user Address
    app.get('/user/address/:userId', userController.getUserAddress);

    // login  employee
    app.post('/user/login', userController.login);

    // login  employee
    app.get('/user/logout', userController.logout);

    // generate otp
    app.post('/otp/generate', otpController.generateOtp);

    // generate otp
    app.post('/otp/verify', otpController.verifyOtp);

    // reset password
    app.post('/password/reset', userController.resetPwd);

    // Get Profile
    app.get('/user/:userId', userController.getProfile);

    // Get Profile by userType
    app.get('/users', userController.getUsersByType);

    // Update Profile
    app.put('/user', userController.updateProfile);

    // create category
    app.post('/category', catController.createCategory);

    // create favcategory
    app.post('/favcategory', catController.createFavCategory);

    // update favcategory
    app.put('/favcategory', catController.updateFavCategory);

    // update category
    app.put('/category', catController.updateCategory);

    // get All category
    app.get('/category', catController.getAllCategory);

    // get All category By user
    app.get('/category/:userId', catController.getAllCategoryByUser);

    // get  category by id
    app.get('/category/:categoryId', catController.getCategoryById);

    // create csub ategory
    app.post('/subcategory', catController.createSubCategory);

    // update subcategory
    app.put('/subcategory', catController.updateSubCategory);

    // get All category
    app.get('/subcategory', catController.getAllSubCategory);

    // get  sub category by cat id
    app.get('/subcategory/:categoryId', catController.getSubCategoryByCatId);

    // create cms
    app.post('/cmspage', cmsController.createCmsPage);

    // get All cms pages
    app.get('/cmspage', cmsController.getAllCms);

    // update cms pages
    app.put('/cmspage', cmsController.updateCmsPage);

    // create Area
    app.post('/area', areaController.createArea);

    // get All Area
    app.get('/area', areaController.getAllArea);

    // update cArea
    app.put('/area', areaController.updateArea);

    app.get('/excel', areaController.excelGenrate);
    app.get('/excel/import', upload.single('file'), areaController.excelImport);

    // create Label
    app.post('/label', labelController.createLabel);

    // get ALL Label
    app.get('/label', labelController.getAllLabel);

    // Update Label
    app.put('/label', labelController.updateLabel);

    // Create Ticket
    app.post('/ticket', ticketController.createTicket);

    // Get All Ticket
    app.get('/ticket', ticketController.getAllTickets);
    // get Ticket analysis
    app.get('/ticket/analysis', ticketController.getTicketAnysis);

    // create Amenties
    app.post('/amenties', amentiesController.createAmenties);

    // get ALL amenties
    app.get('/amenties', amentiesController.getAllAmenties);

    // Update amenties
    app.put('/amenties', amentiesController.updateAmenties);

    // create Offers
    app.post('/offers', offersController.createOffers);

    // get offers analysis
    app.get('/offers/analysis', offersController.offerAnalysis);

    // get ALL offers
    app.get('/offers', offersController.getAllOffers);

    // create events
    app.post('/events', eventsController.createEvents);

    // get ALL events
    app.get('/events', eventsController.getAllEvents);

    // get events analysis
    app.get('/events/analysis', eventsController.eventAnalysis);

    // create eplore
    app.post('/explorerPage', explorePageController.createExplorer);

    // get eplore
    app.get('/explorerPage', explorePageController.getExplorer);

    // update setting
    app.put('/setting', settingController.updateSetting);

    // create location
    app.post('/location', locationController.createLocation);

    // get location
    app.get('/location', locationController.getLocation);

    // update location
    app.put('/location', locationController.updateLocation);

    // Create Bussiness
    app.post('/business', bussinessController.createBussiness);
    app.post('/business/nearBy', bussinessController.getNearBy);

    // Get All Bussiness
    app.get('/business', bussinessController.getAllBussiness);

    // Get Bussiness by bussinessId
    app.get('/business/:businessId', bussinessController.getBussinessById);

    // Update Bussiness by package
    app.put('/business/package', bussinessController.updatePackageInBussiness);

    // Get Business stats
    app.get('/bussiness/analysis', bussinessController.getBusinessStat);

    // Get LATEST business INFO
    app.get('/bussiness/recent', bussinessController.getLatestBusiness);

    // Create Package
    app.post('/package', packageController.createPackage);

    // get ALL Package
    app.get('/package', packageController.getAllPackage);

    // update Package
    app.put('/package', packageController.updatePackage);

    // Retrieve a single package with packageId
    app.get('/package/:packageId', packageController.packfindid);

    // excel dowload
    app.get('/excel/user', userController.userexcelGenrate);
    app.get('/excel/package', packageController.packageexcelgenerate);

    app.get('/excel/offer', offersController.offerexcelgenerate);

    app.get('/excel/event', eventsController.eventexcelgenerate);

    app.get('/excel/business', bussinessController.businessexcelGenrate);

    app.post('/review', ratingController.createReview);
    app.get('/review/:businessId', ratingController.getReviewByBusId);
    app.get('/reviews/:userId', ratingController.getReviewByUserId);
    app.post('/image', imageController.createImages);
    app.get('/image/:businessId', imageController.getAllImagesById);

    app.get(
        '/graph/review/:businessId',
        ratingController.getReviewGraphByBusinessIdonMonthBasis
    );

    app.get('/graph/ticket', ticketController.getTicketsRecordsOnMonthBasis);

    // upload a new image
    app.post('/upload/image', controller.uploadImage);

    // download a new image
    app.get('/download/image/:name', controller.downloadImage);

    app.post('/splashScreesn', screenController.createScreens);
    app.get('/splashScreesn', screenController.getAllScreens);
    app.get('/trxnHistory/:userId', trxnController.getTrxnhistoryByUser);
    app.post('/trxnHistory', trxnController.createTxnHistory);
};
