const express = require('express');
const bodyParser = require('body-parser');
var swaggerUi = require('swagger-ui-express'),
    swaggerDocument = require('./swagger.json');

//const commonErrors = require('common-errors');

const cors = require('cors');
const responseHandler = require('./app/service/helper');
//const rateLimiterUsingThirdParty = require('./app/config/rateLimiter.js');
// Configuring the  mongo database
const mongodbConfig = require('./app/config/constant.js');

const app = express();

var corsOptions = {
    origin: 'http://139.59.74.139:8083',
};
app.use(cors(corsOptions));

app.use(bodyParser.json({ limit: '50mb' }));
app.use(
    bodyParser.urlencoded({
        limit: '50mb',
        extended: true,
        parameterLimit: 50000,
    })
);

const mongoose = require('mongoose');
mongoose.Promise = global.Promise;
// Connecting to the database
mongoose
    .connect(mongodbConfig.url, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    })
    .then(() => {
        console.log('\n Successfully connected to the Mongo database');
    })
    .catch((err) => {
        console.log('Could not connect to the database. Exiting now...', err);
        process.exit();
    });

//const db = require('./app/models');
//db.sequelize.sync();

// set port, listen for requests
const PORT = process.env.PORT || 9090;
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
// use basic HTTP auth to secure the api
app.use(responseHandler.basicAuth);
//app.use(rateLimiterUsingThirdParty.customRedisRateLimiter);
require('./app/routes/routes.js')(app);

app.use(responseHandler.OkHandler);
app.use(responseHandler.errorHandler);

//app.use(commonErrors.middleware.errorHandler);

var server = app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}.`);
});
server.timeout = 1000;
